# ONE Mantra - API Contracts & Data Schemas

## Lead Management Service API

```yaml
openapi: 3.0.3
info:
  title: ONE Mantra Lead Management API
  version: 1.0.0
  description: AI-powered lead management and qualification service

paths:
  /api/v1/leads:
    post:
      summary: Create new lead
      security:
        - bearerAuth: []
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/CreateLeadRequest'
      responses:
        '201':
          description: Lead created successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LeadResponse'

    get:
      summary: List leads with filters
      security:
        - bearerAuth: []
      parameters:
        - name: status
          in: query
          schema:
            type: string
            enum: [new, qualified, contacted, converted]
        - name: source
          in: query
          schema:
            type: string
        - name: partner_id
          in: query
          schema:
            type: string
            format: uuid
        - name: page
          in: query
          schema:
            type: integer
            default: 1
        - name: limit
          in: query
          schema:
            type: integer
            default: 20
            maximum: 100
      responses:
        '200':
          description: List of leads
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LeadListResponse'

  /api/v1/leads/{lead_id}:
    get:
      summary: Get lead details
      security:
        - bearerAuth: []
      parameters:
        - name: lead_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      responses:
        '200':
          description: Lead details
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LeadDetailResponse'

    put:
      summary: Update lead
      security:
        - bearerAuth: []
      parameters:
        - name: lead_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/UpdateLeadRequest'
      responses:
        '200':
          description: Lead updated successfully
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/LeadResponse'

  /api/v1/leads/{lead_id}/qualify:
    post:
      summary: AI-driven lead qualification
      security:
        - bearerAuth: []
      parameters:
        - name: lead_id
          in: path
          required: true
          schema:
            type: string
            format: uuid
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/QualificationRequest'
      responses:
        '200':
          description: Lead qualification completed
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/QualificationResponse'

components:
  schemas:
    CreateLeadRequest:
      type: object
      required:
        - contact_info
        - source
      properties:
        contact_info:
          $ref: '#/components/schemas/ContactInfo'
        source:
          type: string
          enum: [website, social_media, referral, channel_partner, advertisement]
        channel_partner_id:
          type: string
          format: uuid
        property_interests:
          type: array
          items:
            type: string
            format: uuid
        budget_range:
          $ref: '#/components/schemas/BudgetRange'
        initial_notes:
          type: string
          maxLength: 1000

    ContactInfo:
      type: object
      required:
        - name
        - phone_number
      properties:
        name:
          type: string
          maxLength: 255
        phone_number:
          type: string
          pattern: '^[+]?[1-9]\d{1,14}$'
        email:
          type: string
          format: email
        address:
          type: string
          maxLength: 500

    BudgetRange:
      type: object
      properties:
        min_amount:
          type: number
          minimum: 0
        max_amount:
          type: number
          minimum: 0
        currency:
          type: string
          default: "INR"

    LeadResponse:
      type: object
      properties:
        lead_id:
          type: string
          format: uuid
        user_id:
          type: string
          format: uuid
        contact_info:
          $ref: '#/components/schemas/ContactInfo'
        source:
          type: string
        status:
          type: string
          enum: [new, qualified, contacted, visit_scheduled, visited, eoi_submitted, converted, dropped]
        bant_score:
          type: integer
          minimum: 0
          maximum: 100
        qualification_data:
          type: object
        assigned_to:
          type: string
          format: uuid
        created_at:
          type: string
          format: date-time
        updated_at:
          type: string
          format: date-time

    QualificationRequest:
      type: object
      required:
        - conversation_data
      properties:
        conversation_data:
          type: object
          description: Chat/interaction history for AI analysis
        additional_context:
          type: object
          description: Any additional context for qualification

    QualificationResponse:
      type: object
      properties:
        lead_id:
          type: string
          format: uuid
        bant_score:
          type: integer
          minimum: 0
          maximum: 100
        qualification_details:
          type: object
          properties:
            budget_qualified:
              type: boolean
            authority_verified:
              type: boolean
            need_identified:
              type: boolean
            timeline_defined:
              type: boolean
        recommended_actions:
          type: array
          items:
            type: object
            properties:
              action:
                type: string
              priority:
                type: string
                enum: [high, medium, low]
              due_date:
                type: string
                format: date-time
        ai_insights:
          type: object
          description: AI-generated insights about the lead

  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
```

## Event Schemas

```json
{
  "LeadCreatedEvent": {
    "eventId": "string (uuid)",
    "eventType": "LEAD_CREATED",
    "timestamp": "string (ISO 8601)",
    "source": "lead-management-service",
    "version": "1.0.0",
    "data": {
      "lead_id": "string (uuid)",
      "user_id": "string (uuid)",
      "source": "string",
      "channel_partner_id": "string (uuid, optional)",
      "initial_data": {
        "contact_info": "object",
        "property_interests": "array",
        "budget_range": "object"
      },
      "created_by": "string (uuid)"
    }
  },
  
  "LeadQualifiedEvent": {
    "eventId": "string (uuid)",
    "eventType": "LEAD_QUALIFIED",
    "timestamp": "string (ISO 8601)",
    "source": "ai-gateway-service",
    "version": "1.0.0",
    "data": {
      "lead_id": "string (uuid)",
      "bant_score": "number (0-100)",
      "qualification_details": "object",
      "recommended_actions": "array",
      "qualified_by": "ai-agent",
      "qualification_timestamp": "string (ISO 8601)"
    }
  },
  
  "BookingConfirmedEvent": {
    "eventId": "string (uuid)",
    "eventType": "BOOKING_CONFIRMED",
    "timestamp": "string (ISO 8601)",
    "source": "booking-service",
    "version": "1.0.0",
    "data": {
      "booking_id": "string (uuid)",
      "lead_id": "string (uuid)",
      "unit_id": "string (uuid)",
      "user_id": "string (uuid)",
      "booking_amount": "number",
      "total_amount": "number",
      "payment_schedule": "array",
      "channel_partner_id": "string (uuid, optional)"
    }
  },
  
  "PaymentProcessedEvent": {
    "eventId": "string (uuid)",
    "eventType": "PAYMENT_PROCESSED",
    "timestamp": "string (ISO 8601)",
    "source": "payment-service",
    "version": "1.0.0",
    "data": {
      "transaction_id": "string (uuid)",
      "booking_id": "string (uuid)",
      "user_id": "string (uuid)",
      "amount": "number",
      "payment_method": "string",
      "gateway": "string",
      "gateway_transaction_id": "string",
      "status": "string (completed|failed|refunded)"
    }
  },
  
  "MaintenanceRequestCreatedEvent": {
    "eventId": "string (uuid)",
    "eventType": "MAINTENANCE_REQUEST_CREATED",
    "timestamp": "string (ISO 8601)",
    "source": "society-management-service",
    "version": "1.0.0",
    "data": {
      "request_id": "string (uuid)",
      "unit_id": "string (uuid)",
      "resident_id": "string (uuid)",
      "category": "string",
      "priority": "string (low|medium|high|critical)",
      "title": "string",
      "description": "string",
      "images": "array of URLs",
      "location_details": "object"
    }
  },
  
  "VisitorCheckedInEvent": {
    "eventId": "string (uuid)",
    "eventType": "VISITOR_CHECKED_IN",
    "timestamp": "string (ISO 8601)",
    "source": "visitor-management-service",
    "version": "1.0.0",
    "data": {
      "entry_id": "string (uuid)",
      "visitor_name": "string",
      "visitor_category": "string",
      "host_user_id": "string (uuid)",
      "unit_id": "string (uuid)",
      "check_in_time": "string (ISO 8601)",
      "expected_duration": "number (minutes)",
      "approved_by": "string (uuid)",
      "entry_method": "string (qr_code|manual|pre_approved)"
    }
  },
  
  "SOSAlertTriggeredEvent": {
    "eventId": "string (uuid)",
    "eventType": "SOS_ALERT_TRIGGERED",
    "timestamp": "string (ISO 8601)",
    "source": "security-service",
    "version": "1.0.0",
    "data": {
      "alert_id": "string (uuid)",
      "user_id": "string (uuid)",
      "unit_id": "string (uuid)",
      "alert_type": "string (sos|panic|medical|fire|security)",
      "location": "object (lat, lng, address)",
      "emergency_contacts": "array",
      "additional_info": "object",
      "severity": "string (low|medium|high|critical)"
    }
  }
}
```

## Database Migration Scripts

```sql
-- Migration: 001_initial_schema.sql
-- Create initial database schema for ONE Mantra

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create custom types
CREATE TYPE user_role_enum AS ENUM (
    'prospect', 'channel_partner', 'resident', 'building_manager',
    'security_staff', 'maintenance_staff', 'admin', 'nri_buyer'
);

CREATE TYPE lead_source_enum AS ENUM (
    'website', 'social_media', 'referral', 'channel_partner', 
    'advertisement', 'walk_in', 'nri_helpdesk'
);

CREATE TYPE lead_status_enum AS ENUM (
    'new', 'qualified', 'contacted', 'visit_scheduled', 
    'visited', 'eoi_submitted', 'converted', 'dropped'
);

-- Users table
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role user_role_enum NOT NULL,
    profile_data JSONB DEFAULT '{}',
    preferences JSONB DEFAULT '{}',
    locale VARCHAR(10) DEFAULT 'en-IN',
    biometric_key_ref VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    last_login_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_active ON users(is_active);

-- Properties table
CREATE TABLE properties (
    property_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    location JSONB NOT NULL,
    project_tier VARCHAR(20) DEFAULT 'standard',
    amenities JSONB DEFAULT '[]',
    vr_tour_urls JSONB DEFAULT '[]',
    status VARCHAR(20) DEFAULT 'upcoming',
    rera_number VARCHAR(100),
    possession_date DATE,
    metadata JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create property indexes
CREATE INDEX idx_properties_status ON properties(status);
CREATE INDEX idx_properties_tier ON properties(project_tier);
CREATE INDEX idx_properties_active ON properties(is_active);

-- Units table
CREATE TABLE units (
    unit_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID REFERENCES properties(property_id) ON DELETE CASCADE,
    unit_number VARCHAR(50) NOT NULL,
    floor_number INTEGER,
    unit_type VARCHAR(50),
    carpet_area DECIMAL(10,2),
    built_up_area DECIMAL(10,2),
    base_price DECIMAL(15,2),
    current_price DECIMAL(15,2),
    status VARCHAR(20) DEFAULT 'available',
    amenities_included JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(property_id, unit_number)
);

-- Create unit indexes
CREATE INDEX idx_units_property ON units(property_id);
CREATE INDEX idx_units_status ON units(status);
CREATE INDEX idx_units_type ON units(unit_type);
CREATE INDEX idx_units_price_range ON units(current_price);

-- Leads table
CREATE TABLE leads (
    lead_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    source lead_source_enum NOT NULL,
    channel_partner_id UUID REFERENCES users(user_id),
    property_interests JSONB DEFAULT '[]',
    budget_range JSONB DEFAULT '{}',
    bant_score INTEGER CHECK (bant_score >= 0 AND bant_score <= 100),
    qualification_data JSONB DEFAULT '{}',
    status lead_status_enum DEFAULT 'new',
    interaction_history JSONB DEFAULT '[]',
    assigned_to UUID REFERENCES users(user_id),
    last_contacted_at TIMESTAMP,
    conversion_probability DECIMAL(5,2),
    tags JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create lead indexes
CREATE INDEX idx_leads_user ON leads(user_id);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_source ON leads(source);
CREATE INDEX idx_leads_partner ON leads(channel_partner_id);
CREATE INDEX idx_leads_assigned ON leads(assigned_to);
CREATE INDEX idx_leads_score ON leads(bant_score);

-- Bookings table
CREATE TABLE bookings (
    booking_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    lead_id UUID REFERENCES leads(lead_id),
    unit_id UUID REFERENCES units(unit_id),
    user_id UUID REFERENCES users(user_id),
    booking_amount DECIMAL(15,2) NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    payment_schedule JSONB DEFAULT '[]',
    documents_uploaded JSONB DEFAULT '[]',
    status VARCHAR(30) DEFAULT 'initiated',
    agreement_signed_at TIMESTAMP,
    possession_date DATE,
    cancellation_reason TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create booking indexes
CREATE INDEX idx_bookings_lead ON bookings(lead_id);
CREATE INDEX idx_bookings_unit ON bookings(unit_id);
CREATE INDEX idx_bookings_user ON bookings(user_id);
CREATE INDEX idx_bookings_status ON bookings(status);

-- Transactions table
CREATE TABLE transactions (
    transaction_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id UUID REFERENCES bookings(booking_id),
    user_id UUID REFERENCES users(user_id),
    amount DECIMAL(15,2) NOT NULL,
    transaction_type VARCHAR(30) NOT NULL,
    payment_method VARCHAR(50),
    gateway VARCHAR(30),
    gateway_reference VARCHAR(255),
    gateway_response JSONB DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'initiated',
    retry_count INTEGER DEFAULT 0,
    failure_reason TEXT,
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create transaction indexes
CREATE INDEX idx_transactions_booking ON transactions(booking_id);
CREATE INDEX idx_transactions_user ON transactions(user_id);
CREATE INDEX idx_transactions_status ON transactions(status);
CREATE INDEX idx_transactions_gateway ON transactions(gateway);
CREATE INDEX idx_transactions_type ON transactions(transaction_type);

-- Commission terms table
CREATE TABLE commission_terms (
    term_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID REFERENCES users(user_id),
    property_id UUID REFERENCES properties(property_id),
    base_percentage DECIMAL(5,2) NOT NULL,
    tier_rates JSONB DEFAULT '[]',
    clawback_rules JSONB DEFAULT '{}',
    bonus_triggers JSONB DEFAULT '[]',
    effective_from DATE NOT NULL,
    effective_until DATE,
    created_by UUID REFERENCES users(user_id),
    status VARCHAR(20) DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create commission indexes
CREATE INDEX idx_commission_partner ON commission_terms(partner_id);
CREATE INDEX idx_commission_property ON commission_terms(property_id);
CREATE INDEX idx_commission_status ON commission_terms(status);
CREATE INDEX idx_commission_dates ON commission_terms(effective_from, effective_until);

-- Maintenance requests table
CREATE TABLE maintenance_requests (
    request_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    unit_id UUID REFERENCES units(unit_id),
    resident_id UUID REFERENCES users(user_id),
    category VARCHAR(30) NOT NULL,
    priority VARCHAR(10) DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'open',
    assigned_to UUID REFERENCES users(user_id),
    images JSONB DEFAULT '[]',
    estimated_cost DECIMAL(10,2),
    actual_cost DECIMAL(10,2),
    scheduled_date DATE,
    completed_at TIMESTAMP,
    resident_satisfaction INTEGER CHECK (resident_satisfaction >= 1 AND resident_satisfaction <= 5),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create maintenance indexes
CREATE INDEX idx_maintenance_unit ON maintenance_requests(unit_id);
CREATE INDEX idx_maintenance_resident ON maintenance_requests(resident_id);
CREATE INDEX idx_maintenance_status ON maintenance_requests(status);
CREATE INDEX idx_maintenance_category ON maintenance_requests(category);
CREATE INDEX idx_maintenance_priority ON maintenance_requests(priority);
CREATE INDEX idx_maintenance_assigned ON maintenance_requests(assigned_to);

-- Visitor entries table
CREATE TABLE visitor_entries (
    entry_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    visitor_name VARCHAR(255) NOT NULL,
    visitor_phone VARCHAR(20),
    visitor_category VARCHAR(30) NOT NULL,
    host_user_id UUID REFERENCES users(user_id),
    unit_id UUID REFERENCES units(unit_id),
    purpose TEXT,
    vehicle_number VARCHAR(20),
    photo_url VARCHAR(500),
    qr_code VARCHAR(255) UNIQUE,
    approved_by UUID REFERENCES users(user_id),
    check_in_time TIMESTAMP,
    check_out_time TIMESTAMP,
    expected_duration INTEGER, -- in minutes
    status VARCHAR(20) DEFAULT 'pending',
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create visitor indexes
CREATE INDEX idx_visitors_host ON visitor_entries(host_user_id);
CREATE INDEX idx_visitors_unit ON visitor_entries(unit_id);
CREATE INDEX idx_visitors_status ON visitor_entries(status);
CREATE INDEX idx_visitors_category ON visitor_entries(visitor_category);
CREATE INDEX idx_visitors_check_in ON visitor_entries(check_in_time);
CREATE INDEX idx_visitors_qr ON visitor_entries(qr_code);

-- Referrals table
CREATE TABLE referrals (
    referral_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    referrer_id UUID REFERENCES users(user_id),
    referee_phone VARCHAR(20) NOT NULL,
    referee_id UUID REFERENCES users(user_id),
    referral_code VARCHAR(50) UNIQUE NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    points_earned INTEGER DEFAULT 0,
    reward_amount DECIMAL(10,2),
    reward_type VARCHAR(30),
    conversion_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Create referral indexes
CREATE INDEX idx_referrals_referrer ON referrals(referrer_id);
CREATE INDEX idx_referrals_referee ON referrals(referee_id);
CREATE INDEX idx_referrals_code ON referrals(referral_code);
CREATE INDEX idx_referrals_status ON referrals(status);
CREATE INDEX idx_referrals_phone ON referrals(referee_phone);

-- Blockchain records table
CREATE TABLE blockchain_records (
    record_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    agreement_id VARCHAR(255) NOT NULL,
    document_hash VARCHAR(64) NOT NULL,
    parties_involved JSONB NOT NULL,
    agreement_type VARCHAR(30) NOT NULL,
    effective_date DATE NOT NULL,
    blockchain_tx_hash VARCHAR(255),
    ledger_status VARCHAR(20) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create blockchain indexes
CREATE INDEX idx_blockchain_agreement ON blockchain_records(agreement_id);
CREATE INDEX idx_blockchain_hash ON blockchain_records(document_hash);
CREATE INDEX idx_blockchain_status ON blockchain_records(ledger_status);
CREATE INDEX idx_blockchain_type ON blockchain_records(agreement_type);

-- Audit logs table
CREATE TABLE audit_logs (
    log_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) NOT NULL,
    record_id VARCHAR(255) NOT NULL,
    action VARCHAR(20) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSONB,
    new_values JSONB,
    changed_by UUID REFERENCES users(user_id),
    changed_at TIMESTAMP DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT
);

-- Create audit indexes
CREATE INDEX idx_audit_table ON audit_logs(table_name);
CREATE INDEX idx_audit_record ON audit_logs(record_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
CREATE INDEX idx_audit_user ON audit_logs(changed_by);
CREATE INDEX idx_audit_timestamp ON audit_logs(changed_at);

-- Create triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to all tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON properties 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_units_updated_at BEFORE UPDATE ON units 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_commission_terms_updated_at BEFORE UPDATE ON commission_terms 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_maintenance_requests_updated_at BEFORE UPDATE ON maintenance_requests 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_referrals_updated_at BEFORE UPDATE ON referrals 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```