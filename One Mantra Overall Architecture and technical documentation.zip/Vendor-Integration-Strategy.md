# ONE Mantra - Vendor Integration & Partnership Strategy

## 1. VR Tour Provider Integration

### Primary Vendor: Matterport

#### Technical Integration Specifications

```typescript
// VR Tour Service Integration
interface MatterportConfig {
  apiKey: string;
  organizationId: string;
  baseUrl: string;
  webhookSecret: string;
}

class MatterportIntegration {
  private config: MatterportConfig;
  
  constructor(config: MatterportConfig) {
    this.config = config;
  }
  
  async uploadTourAssets(propertyId: string, assets: TourAssets): Promise<TourUploadResult> {
    const uploadRequests = assets.images.map(async (image) => {
      const formData = new FormData();
      formData.append('file', image.buffer);
      formData.append('metadata', JSON.stringify({
        propertyId,
        roomType: image.roomType,
        timestamp: new Date().toISOString()
      }));
      
      return await fetch(`${this.config.baseUrl}/api/v1/uploads`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.apiKey}`,
          'X-Organization-Id': this.config.organizationId
        },
        body: formData
      });
    });
    
    const uploadResults = await Promise.all(uploadRequests);
    return this.processUploadResults(uploadResults);
  }
  
  async createVirtualTour(tourData: TourCreationData): Promise<VirtualTour> {
    const response = await fetch(`${this.config.baseUrl}/api/v1/models`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.config.apiKey}`,
        'Content-Type': 'application/json',
        'X-Organization-Id': this.config.organizationId
      },
      body: JSON.stringify({
        name: tourData.propertyName,
        description: tourData.description,
        images: tourData.imageIds,
        floorplan: tourData.floorPlanData,
        tags: tourData.amenities
      })
    });
    
    if (!response.ok) {
      throw new Error(`Matterport API error: ${response.statusText}`);
    }
    
    const result = await response.json();
    return this.formatTourResponse(result);
  }
  
  async getTourEmbedCode(modelId: string, customizations: EmbedCustomizations): Promise<EmbedCode> {
    const embedUrl = `${this.config.baseUrl}/show/?m=${modelId}`;
    const params = new URLSearchParams({
      play: customizations.autoplay ? '1' : '0',
      qs: customizations.hideUI ? '1' : '0',
      brand: '0', // Hide Matterport branding
      help: '0',  // Hide help button
      hr: customizations.highRes ? '1' : '0'
    });
    
    return {
      iframe: `<iframe width="100%" height="400" src="${embedUrl}&${params}" frameborder="0" allowfullscreen></iframe>`,
      directUrl: `${embedUrl}&${params}`,
      mobileDeepLink: `onemantra://vr-tour/${modelId}`,
      thumbnailUrl: `${this.config.baseUrl}/api/v1/models/${modelId}/thumb`
    };
  }
}

// Usage in property service
class PropertyVRService {
  private matterport: MatterportIntegration;
  
  async processPropertyVRTour(propertyId: string, rawAssets: RawTourAssets): Promise<void> {
    try {
      // Upload and process 360° images
      const uploadResult = await this.matterport.uploadTourAssets(propertyId, rawAssets);
      
      // Create virtual tour
      const tour = await this.matterport.createVirtualTour({
        propertyName: `Mantra Property ${propertyId}`,
        description: rawAssets.description,
        imageIds: uploadResult.imageIds,
        floorPlanData: rawAssets.floorPlan,
        amenities: rawAssets.amenityTags
      });
      
      // Generate embed codes for different platforms
      const embedCodes = await this.matterport.getTourEmbedCode(tour.id, {
        autoplay: false,
        hideUI: true,
        highRes: true
      });
      
      // Update property record
      await this.propertyRepository.updateVRTourData(propertyId, {
        matterportId: tour.id,
        embedCodes: embedCodes,
        tourUrl: tour.publicUrl,
        thumbnails: tour.thumbnails,
        processingStatus: 'completed',
        createdAt: new Date()
      });
      
      // Notify relevant teams
      await this.notificationService.notifyVRTourReady(propertyId);
      
    } catch (error) {
      console.error('VR tour processing failed:', error);
      await this.handleVRTourFailure(propertyId, error);
    }
  }
}
```

#### Alternative Provider: 360° Tour Solution

```yaml
# Alternative VR Provider Configuration
alternative_vr_providers:
  - name: "Kuula"
    api_endpoint: "https://kuula.co/api/v1"
    pricing: "$29/month for 100 tours"
    features:
      - "Custom branding"
      - "Hotspot annotations"
      - "Floor plan integration"
      - "Analytics dashboard"
    
  - name: "Ricoh Theta"
    api_endpoint: "https://api.ricoh-theta.com"
    pricing: "Hardware cost + custom development"
    features:
      - "High-quality 360° capture"
      - "Real-time streaming"
      - "Custom mobile apps"
      - "Offline viewing support"
```

## 2. IoT Platform Integration

### Primary Vendor: AWS IoT Core + Custom Device Partners

#### Smart Meter Integration (DLMS/COSEM Protocol)

```python
# Smart Meter Data Collection Service
import asyncio
import json
from datetime import datetime
from typing import Dict, List
import paho.mqtt.client as mqtt
from dlms_cosem import DlmsConnection

class SmartMeterIntegration:
    def __init__(self, mqtt_broker: str, device_registry: DeviceRegistry):
        self.mqtt_client = mqtt.Client()
        self.device_registry = device_registry
        self.dlms_connections = {}
        
        # Configure MQTT client
        self.mqtt_client.on_connect = self.on_mqtt_connect
        self.mqtt_client.on_message = self.on_mqtt_message
        self.mqtt_client.connect(mqtt_broker, 1883, 60)
    
    def on_mqtt_connect(self, client, userdata, flags, rc):
        """Subscribe to device telemetry topics"""
        client.subscribe("meters/+/readings")
        client.subscribe("meters/+/alerts")
        print(f"Connected to MQTT broker with result code {rc}")
    
    def on_mqtt_message(self, client, userdata, msg):
        """Process incoming meter readings"""
        try:
            topic_parts = msg.topic.split('/')
            device_id = topic_parts[1]
            message_type = topic_parts[2]
            
            payload = json.loads(msg.payload.decode())
            
            if message_type == 'readings':
                asyncio.create_task(self.process_meter_reading(device_id, payload))
            elif message_type == 'alerts':
                asyncio.create_task(self.process_meter_alert(device_id, payload))
                
        except Exception as e:
            print(f"Error processing MQTT message: {e}")
    
    async def process_meter_reading(self, device_id: str, reading_data: Dict):
        """Process and store meter readings"""
        device = await self.device_registry.get_device(device_id)
        
        if not device:
            print(f"Unknown device: {device_id}")
            return
        
        # Parse DLMS/COSEM data
        reading = {
            'device_id': device_id,
            'unit_id': device.unit_id,
            'property_id': device.property_id,
            'meter_type': reading_data.get('meter_type', 'electricity'),
            'register_value': reading_data.get('register_value'),
            'unit': reading_data.get('unit', 'kWh'),
            'timestamp': datetime.fromisoformat(reading_data.get('timestamp')),
            'quality': reading_data.get('quality', 'good')
        }
        
        # Store reading
        await self.meter_service.store_reading(reading)
        
        # Check for anomalies
        anomaly = await self.detect_usage_anomaly(device_id, reading)
        if anomaly:
            await self.alert_service.trigger_usage_anomaly_alert(
                device.unit_id, 
                anomaly
            )
        
        # Update real-time dashboard
        await self.websocket_service.broadcast_meter_update(
            device.unit_id, 
            reading
        )
    
    async def detect_usage_anomaly(self, device_id: str, current_reading: Dict) -> Dict:
        """Detect unusual consumption patterns"""
        # Get historical data for comparison
        historical_data = await self.meter_service.get_usage_pattern(
            device_id, 
            days=30
        )
        
        if not historical_data:
            return None
        
        # Calculate averages and thresholds
        avg_daily_usage = sum(historical_data) / len(historical_data)
        threshold = avg_daily_usage * 1.5  # 50% above average
        
        current_usage = current_reading['register_value']
        
        if current_usage > threshold:
            return {
                'type': 'high_usage',
                'current_usage': current_usage,
                'average_usage': avg_daily_usage,
                'threshold_exceeded': (current_usage - threshold) / threshold * 100,
                'detected_at': datetime.utcnow()
            }
        
        return None

# Device Registry Service
class DeviceRegistry:
    def __init__(self, database):
        self.db = database
    
    async def register_smart_meter(self, device_data: Dict) -> str:
        """Register a new smart meter device"""
        device_id = f"meter_{device_data['serial_number']}"
        
        await self.db.devices.insert_one({
            'device_id': device_id,
            'device_type': 'smart_meter',
            'serial_number': device_data['serial_number'],
            'unit_id': device_data['unit_id'],
            'property_id': device_data['property_id'],
            'meter_type': device_data['meter_type'],  # electricity, water, gas
            'manufacturer': device_data['manufacturer'],
            'model': device_data['model'],
            'installation_date': datetime.utcnow(),
            'calibration_date': device_data.get('calibration_date'),
            'communication_protocol': 'DLMS/COSEM',
            'status': 'active',
            'location': device_data.get('location'),
            'configuration': device_data.get('configuration', {})
        })
        
        return device_id
    
    async def get_device(self, device_id: str) -> Dict:
        """Get device information"""
        return await self.db.devices.find_one({'device_id': device_id})
```

#### CCTV Integration (ONVIF Protocol)

```python
# CCTV Integration Service
import cv2
from onvif import ONVIFCamera
from datetime import datetime, timedelta
import asyncio

class CCTVIntegration:
    def __init__(self, rtsp_streams: Dict[str, str]):
        self.rtsp_streams = rtsp_streams
        self.active_cameras = {}
        self.motion_detectors = {}
    
    async def initialize_camera(self, camera_id: str, camera_config: Dict):
        """Initialize ONVIF camera connection"""
        try:
            camera = ONVIFCamera(
                camera_config['ip_address'],
                camera_config['port'],
                camera_config['username'],
                camera_config['password']
            )
            
            # Create media service
            media_service = camera.create_media_service()
            profiles = media_service.GetProfiles()
            
            # Get stream URI
            stream_uri = media_service.GetStreamUri({
                'StreamSetup': {
                    'Stream': 'RTP-Unicast',
                    'Transport': {'Protocol': 'RTSP'}
                },
                'ProfileToken': profiles[0].token
            })
            
            self.active_cameras[camera_id] = {
                'camera': camera,
                'stream_uri': stream_uri.Uri,
                'config': camera_config
            }
            
            # Start motion detection
            await self.start_motion_detection(camera_id)
            
        except Exception as e:
            print(f"Failed to initialize camera {camera_id}: {e}")
    
    async def start_motion_detection(self, camera_id: str):
        """Start motion detection for camera"""
        camera_info = self.active_cameras[camera_id]
        
        # Open video stream
        cap = cv2.VideoCapture(camera_info['stream_uri'])
        
        # Background subtractor for motion detection
        bg_subtractor = cv2.createBackgroundSubtractorMOG2(detectShadows=True)
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Apply background subtraction
            fg_mask = bg_subtractor.apply(frame)
            
            # Find contours
            contours, _ = cv2.findContours(
                fg_mask, 
                cv2.RETR_EXTERNAL, 
                cv2.CHAIN_APPROX_SIMPLE
            )
            
            # Check for significant motion
            for contour in contours:
                if cv2.contourArea(contour) > 500:  # Minimum area threshold
                    # Motion detected
                    await self.handle_motion_event(camera_id, frame, contour)
            
            await asyncio.sleep(0.1)  # Process ~10 FPS
        
        cap.release()
    
    async def handle_motion_event(self, camera_id: str, frame, contour):
        """Handle detected motion event"""
        camera_info = self.active_cameras[camera_id]
        
        # Calculate motion area and location
        x, y, w, h = cv2.boundingRect(contour)
        motion_area = w * h
        
        # Create motion event
        motion_event = {
            'camera_id': camera_id,
            'property_id': camera_info['config']['property_id'],
            'location': camera_info['config']['location'],
            'detected_at': datetime.utcnow(),
            'motion_area': motion_area,
            'bounding_box': {'x': x, 'y': y, 'width': w, 'height': h}
        }
        
        # Save frame with motion highlighted
        frame_filename = f"motion_{camera_id}_{int(datetime.utcnow().timestamp())}.jpg"
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.imwrite(f"/var/cctv-clips/{frame_filename}", frame)
        
        motion_event['frame_filename'] = frame_filename
        
        # Check if motion is during restricted hours
        current_hour = datetime.now().hour
        if current_hour >= 22 or current_hour <= 6:
            await self.trigger_security_alert(motion_event)
        
        # Store motion event
        await self.cctv_service.store_motion_event(motion_event)
    
    async def trigger_security_alert(self, motion_event: Dict):
        """Trigger security alert for suspicious motion"""
        alert = {
            'alert_type': 'motion_detected',
            'camera_id': motion_event['camera_id'],
            'property_id': motion_event['property_id'],
            'location': motion_event['location'],
            'detected_at': motion_event['detected_at'],
            'frame_filename': motion_event['frame_filename'],
            'severity': 'medium',
            'auto_generated': True
        }
        
        # Notify security staff
        await self.notification_service.notify_security_staff(alert)
        
        # Record in security dashboard
        await self.security_service.create_incident(alert)
```

## 3. Payment Gateway Integration Strategy

### Multi-Gateway Approach

```typescript
// Payment Gateway Abstraction Layer
interface PaymentGateway {
  createOrder(orderData: OrderData): Promise<PaymentOrder>;
  verifyPayment(paymentId: string): Promise<PaymentVerification>;
  refund(transactionId: string, amount: number): Promise<RefundResult>;
  getTransactionStatus(transactionId: string): Promise<TransactionStatus>;
}

class PaymentGatewayManager {
  private gateways: Map<string, PaymentGateway> = new Map();
  private routingRules: PaymentRoutingRule[] = [];
  
  constructor() {
    // Initialize payment gateways
    this.gateways.set('razorpay', new RazorpayGateway());
    this.gateways.set('payu', new PayUGateway());
    this.gateways.set('paytm', new PaytmGateway());
  }
  
  async processPayment(paymentRequest: PaymentRequest): Promise<PaymentResult> {
    // Determine best gateway based on routing rules
    const gateway = this.selectGateway(paymentRequest);
    
    try {
      // Primary gateway attempt
      const result = await gateway.createOrder(paymentRequest.orderData);
      
      // Log successful routing
      await this.logPaymentRouting(paymentRequest, gateway.name, 'success');
      
      return result;
      
    } catch (error) {
      console.error(`Payment failed on ${gateway.name}:`, error);
      
      // Attempt fallback gateway
      const fallbackGateway = this.selectFallbackGateway(gateway.name, paymentRequest);
      
      if (fallbackGateway) {
        try {
          const fallbackResult = await fallbackGateway.createOrder(paymentRequest.orderData);
          
          await this.logPaymentRouting(paymentRequest, fallbackGateway.name, 'fallback_success');
          
          return fallbackResult;
          
        } catch (fallbackError) {
          await this.logPaymentRouting(paymentRequest, fallbackGateway.name, 'fallback_failed');
          throw fallbackError;
        }
      }
      
      throw error;
    }
  }
  
  private selectGateway(request: PaymentRequest): PaymentGateway {
    // Apply routing rules
    for (const rule of this.routingRules) {
      if (this.matchesRule(request, rule)) {
        return this.gateways.get(rule.gateway);
      }
    }
    
    // Default to Razorpay
    return this.gateways.get('razorpay');
  }
  
  private matchesRule(request: PaymentRequest, rule: PaymentRoutingRule): boolean {
    // Check amount range
    if (rule.minAmount && request.amount < rule.minAmount) return false;
    if (rule.maxAmount && request.amount > rule.maxAmount) return false;
    
    // Check payment method
    if (rule.paymentMethods && !rule.paymentMethods.includes(request.paymentMethod)) {
      return false;
    }
    
    // Check user type
    if (rule.userTypes && !rule.userTypes.includes(request.userType)) {
      return false;
    }
    
    // Check geography
    if (rule.regions && !rule.regions.includes(request.region)) {
      return false;
    }
    
    return true;
  }
}

// Razorpay Implementation
class RazorpayGateway implements PaymentGateway {
  private razorpay: Razorpay;
  
  constructor() {
    this.razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET
    });
  }
  
  async createOrder(orderData: OrderData): Promise<PaymentOrder> {
    const options = {
      amount: orderData.amount * 100, // Convert to paise
      currency: 'INR',
      receipt: `receipt_${orderData.bookingId}`,
      notes: {
        booking_id: orderData.bookingId,
        property_id: orderData.propertyId,
        user_id: orderData.userId
      }
    };
    
    const order = await this.razorpay.orders.create(options);
    
    return {
      orderId: order.id,
      amount: orderData.amount,
      currency: 'INR',
      keyId: process.env.RAZORPAY_KEY_ID,
      gateway: 'razorpay'
    };
  }
  
  async verifyPayment(paymentId: string): Promise<PaymentVerification> {
    try {
      const payment = await this.razorpay.payments.fetch(paymentId);
      
      return {
        verified: payment.status === 'captured',
        status: payment.status,
        amount: payment.amount / 100,
        method: payment.method,
        gatewayData: payment
      };
    } catch (error) {
      return {
        verified: false,
        status: 'failed',
        error: error.message
      };
    }
  }
  
  async refund(transactionId: string, amount: number): Promise<RefundResult> {
    try {
      const refund = await this.razorpay.payments.refund(transactionId, {
        amount: amount * 100 // Convert to paise
      });
      
      return {
        refundId: refund.id,
        amount: refund.amount / 100,
        status: refund.status,
        gateway: 'razorpay'
      };
    } catch (error) {
      throw new Error(`Razorpay refund failed: ${error.message}`);
    }
  }
}

// Payment routing configuration
const paymentRoutingRules: PaymentRoutingRule[] = [
  {
    name: 'Large Amount Transactions',
    minAmount: 500000, // 5L+
    gateway: 'razorpay',
    priority: 1
  },
  {
    name: 'UPI Payments',
    paymentMethods: ['upi'],
    gateway: 'payu',
    priority: 2
  },
  {
    name: 'Wallet Payments',
    paymentMethods: ['wallet'],
    gateway: 'paytm',
    priority: 3
  },
  {
    name: 'NRI Payments',
    userTypes: ['nri_buyer'],
    gateway: 'razorpay', // Better international support
    priority: 4
  },
  {
    name: 'Default Route',
    gateway: 'razorpay',
    priority: 999
  }
];
```

## 4. Document Management & E-Signature Integration

### DocuSign Integration

```typescript
// DocuSign Integration Service
import { ApiClient, EnvelopesApi, EnvelopeDefinition } from 'docusign-esign';

class DocuSignIntegration {
  private apiClient: ApiClient;
  private envelopesApi: EnvelopesApi;
  private accountId: string;
  
  constructor() {
    this.apiClient = new ApiClient();
    this.apiClient.setBasePath(process.env.DOCUSIGN_BASE_PATH);
    this.accountId = process.env.DOCUSIGN_ACCOUNT_ID;
    this.envelopesApi = new EnvelopesApi(this.apiClient);
  }
  
  async createBookingAgreement(bookingData: BookingData, signers: SignerData[]): Promise<string> {
    // Create envelope definition
    const envelopeDefinition: EnvelopeDefinition = {
      emailSubject: `Booking Agreement - ${bookingData.propertyName}`,
      templateId: process.env.DOCUSIGN_BOOKING_TEMPLATE_ID,
      templateRoles: signers.map((signer, index) => ({
        roleName: signer.role,
        name: signer.name,
        email: signer.email,
        clientUserId: signer.userId,
        tabs: {
          textTabs: [
            {
              tabLabel: 'PropertyName',
              value: bookingData.propertyName
            },
            {
              tabLabel: 'BookingAmount',
              value: bookingData.bookingAmount.toString()
            },
            {
              tabLabel: 'BookingDate',
              value: new Date().toDateString()
            }
          ]
        }
      })),
      status: 'sent'
    };
    
    // Create and send envelope
    const results = await this.envelopesApi.createEnvelope(
      this.accountId,
      { envelopeDefinition }
    );
    
    return results.envelopeId;
  }
  
  async getSigningUrl(envelopeId: string, signerUserId: string): Promise<string> {
    const viewRequest = {
      authenticationMethod: 'none',
      clientUserId: signerUserId,
      recipientId: '1',
      returnUrl: `${process.env.APP_BASE_URL}/booking/signing-complete`,
      userName: 'Signing User'
    };
    
    const results = await this.envelopesApi.createRecipientView(
      this.accountId,
      envelopeId,
      { recipientViewRequest: viewRequest }
    );
    
    return results.url;
  }
  
  async checkEnvelopeStatus(envelopeId: string): Promise<EnvelopeStatus> {
    const envelope = await this.envelopesApi.getEnvelope(this.accountId, envelopeId);
    
    return {
      status: envelope.status,
      completedDateTime: envelope.completedDateTime,
      sentDateTime: envelope.sentDateTime,
      signers: envelope.recipients?.signers?.map(signer => ({
        name: signer.name,
        email: signer.email,
        status: signer.status,
        signedDateTime: signer.signedDateTime
      }))
    };
  }
}

// Document Generation Service
class DocumentGenerationService {
  async generateBookingAgreement(bookingData: BookingData): Promise<Buffer> {
    // Use a template engine (like Handlebars) to generate PDF
    const template = await this.loadTemplate('booking-agreement');
    const html = template({
      booking: bookingData,
      property: bookingData.property,
      buyer: bookingData.buyer,
      generatedDate: new Date().toDateString()
    });
    
    // Convert HTML to PDF
    const pdf = await this.htmlToPdf(html);
    return pdf;
  }
  
  private async htmlToPdf(html: string): Promise<Buffer> {
    // Implementation using puppeteer or similar
    const puppeteer = require('puppeteer');
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    await page.setContent(html);
    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: {
        top: '20mm',
        right: '20mm',
        bottom: '20mm',
        left: '20mm'
      }
    });
    
    await browser.close();
    return pdf;
  }
}
```

## 5. Vendor Partnership Agreements & SLAs

### Service Level Agreements Template

```yaml
# Vendor SLA Configuration
vendor_slas:
  vr_tour_provider:
    name: "Matterport"
    sla_metrics:
      - metric: "Tour Processing Time"
        target: "< 24 hours"
        penalty: "10% credit for each day delayed"
      
      - metric: "API Availability"
        target: "99.5% uptime"
        measurement: "Monthly"
        penalty: "Service credits for downtime"
      
      - metric: "Tour Quality"
        target: "4K resolution minimum"
        acceptance_criteria: "Visual inspection passed"
    
    support_terms:
      - level: "P1 - Critical"
        response_time: "2 hours"
        resolution_time: "8 hours"
      
      - level: "P2 - High"
        response_time: "4 hours"
        resolution_time: "24 hours"
  
  payment_gateways:
    razorpay:
      transaction_success_rate: "> 98%"
      api_response_time: "< 3 seconds"
      settlement_time: "T+1 working day"
      support_availability: "24x7"
      
    payu:
      transaction_success_rate: "> 97%"
      api_response_time: "< 5 seconds"
      settlement_time: "T+2 working days"
      
  iot_platform:
    aws_iot_core:
      message_delivery: "99.9% reliability"
      latency: "< 100ms for real-time events"
      data_retention: "1 year minimum"
      security: "End-to-end encryption"

# Cost Structure
vendor_costs:
  matterport:
    setup_fee: "$500 per property"
    monthly_hosting: "$50 per active tour"
    bandwidth: "$0.10 per GB"
    
  razorpay:
    transaction_fee: "2% + GST"
    setup_fee: "$0"
    monthly_fee: "$0"
    international_cards: "3% + GST"
    
  aws_iot_core:
    messages: "$1 per million messages"
    device_shadow: "$1.25 per million updates"
    rules_engine: "$0.15 per million rules executed"
```

### Vendor Evaluation & Selection Criteria

```markdown
# Vendor Selection Scorecard

## Technical Criteria (40 points)
- **API Quality & Documentation** (10 points)
  - RESTful design principles
  - Comprehensive documentation
  - SDK availability
  - Webhook support

- **Scalability & Performance** (10 points)
  - Load handling capacity
  - Response time guarantees
  - Geographic distribution
  - Caching capabilities

- **Security & Compliance** (10 points)
  - Data encryption standards
  - Compliance certifications (ISO, SOC)
  - Security audit reports
  - GDPR/data protection compliance

- **Integration Complexity** (10 points)
  - Development effort required
  - Testing complexity
  - Migration requirements
  - Backward compatibility

## Business Criteria (35 points)
- **Cost Structure** (15 points)
  - Transparent pricing
  - No hidden fees
  - Volume discounts
  - Predictable cost scaling

- **Support Quality** (10 points)
  - Response time guarantees
  - Escalation procedures
  - Technical expertise
  - Documentation quality

- **Company Stability** (10 points)
  - Financial health
  - Market position
  - Customer retention
  - Growth trajectory

## Strategic Criteria (25 points)
- **Feature Roadmap Alignment** (10 points)
  - Future feature plans
  - Innovation track record
  - Technology modernization
  - Platform extensibility

- **Partnership Potential** (10 points)
  - Collaboration willingness
  - Custom development support
  - Joint go-to-market opportunities
  - Reference customer sharing

- **Exit Strategy** (5 points)
  - Data portability
  - Contract termination terms
  - Migration support
  - IP ownership clarity

## Scoring Guidelines
- **90-100 points**: Preferred vendor, proceed with contract negotiation
- **75-89 points**: Qualified vendor, request additional information
- **60-74 points**: Conditional approval, specific concerns must be addressed
- **Below 60 points**: Not recommended
```

## 6. Integration Testing & Quality Assurance

### Vendor Integration Test Suite

```typescript
// Integration Test Framework
class VendorIntegrationTests {
  private testResults: Map<string, TestResult[]> = new Map();
  
  async runVendorIntegrationSuite(vendorName: string): Promise<TestSuiteResult> {
    const tests = this.getVendorTests(vendorName);
    const results: TestResult[] = [];
    
    for (const test of tests) {
      try {
        const startTime = Date.now();
        await test.execute();
        const duration = Date.now() - startTime;
        
        results.push({
          testName: test.name,
          status: 'passed',
          duration,
          details: test.getResults()
        });
      } catch (error) {
        results.push({
          testName: test.name,
          status: 'failed',
          error: error.message,
          details: test.getResults()
        });
      }
    }
    
    this.testResults.set(vendorName, results);
    
    return {
      vendor: vendorName,
      totalTests: tests.length,
      passed: results.filter(r => r.status === 'passed').length,
      failed: results.filter(r => r.status === 'failed').length,
      results
    };
  }
  
  private getVendorTests(vendorName: string): IntegrationTest[] {
    switch (vendorName) {
      case 'matterport':
        return [
          new MatterportAPIConnectionTest(),
          new MatterportUploadTest(),
          new MatterportTourCreationTest(),
          new MatterportWebhookTest()
        ];
      case 'razorpay':
        return [
          new RazorpayOrderCreationTest(),
          new RazorpayPaymentVerificationTest(),
          new RazorpayRefundTest(),
          new RazorpayWebhookTest()
        ];
      default:
        return [];
    }
  }
}

// Example: Matterport Integration Tests
class MatterportAPIConnectionTest implements IntegrationTest {
  name = 'Matterport API Connection Test';
  
  async execute(): Promise<void> {
    const response = await fetch(`${process.env.MATTERPORT_BASE_URL}/api/v1/models`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.MATTERPORT_API_KEY}`,
        'X-Organization-Id': process.env.MATTERPORT_ORG_ID
      }
    });
    
    if (!response.ok) {
      throw new Error(`API connection failed: ${response.statusText}`);
    }
    
    const data = await response.json();
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid API response format');
    }
  }
  
  getResults(): any {
    return { message: 'API connection successful' };
  }
}

class MatterportUploadTest implements IntegrationTest {
  name = 'Matterport Image Upload Test';
  
  async execute(): Promise<void> {
    // Create test image
    const testImageBuffer = await this.createTestImage();
    
    const formData = new FormData();
    formData.append('file', testImageBuffer);
    formData.append('metadata', JSON.stringify({
      test: true,
      propertyId: 'test-property-123'
    }));
    
    const response = await fetch(`${process.env.MATTERPORT_BASE_URL}/api/v1/uploads`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.MATTERPORT_API_KEY}`,
        'X-Organization-Id': process.env.MATTERPORT_ORG_ID
      },
      body: formData
    });
    
    if (!response.ok) {
      throw new Error(`Upload failed: ${response.statusText}`);
    }
    
    const result = await response.json();
    
    if (!result.uploadId) {
      throw new Error('Upload response missing uploadId');
    }
  }
  
  private async createTestImage(): Promise<Buffer> {
    // Generate a simple test image
    const canvas = require('canvas');
    const canvasObj = canvas.createCanvas(800, 600);
    const ctx = canvasObj.getContext('2d');
    
    // Draw test pattern
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(0, 0, 800, 600);
    ctx.fillStyle = '#ffffff';
    ctx.font = '30px Arial';
    ctx.fillText('Test Image', 300, 300);
    
    return canvasObj.toBuffer('image/jpeg');
  }
  
  getResults(): any {
    return { message: 'Image upload successful' };
  }
}

// Automated vendor health monitoring
class VendorHealthMonitor {
  private monitors: Map<string, VendorMonitor> = new Map();
  
  async startMonitoring(): Promise<void> {
    // Initialize vendor monitors
    this.monitors.set('matterport', new MatterportHealthMonitor());
    this.monitors.set('razorpay', new RazorpayHealthMonitor());
    this.monitors.set('aws-iot', new AWSIoTHealthMonitor());
    
    // Run health checks every 5 minutes
    setInterval(async () => {
      for (const [vendorName, monitor] of this.monitors) {
        try {
          const health = await monitor.checkHealth();
          await this.recordHealthMetrics(vendorName, health);
          
          if (health.status !== 'healthy') {
            await this.triggerVendorAlert(vendorName, health);
          }
        } catch (error) {
          console.error(`Health check failed for ${vendorName}:`, error);
          await this.triggerVendorAlert(vendorName, {
            status: 'error',
            message: error.message,
            timestamp: new Date()
          });
        }
      }
    }, 5 * 60 * 1000); // 5 minutes
  }
  
  private async recordHealthMetrics(vendorName: string, health: VendorHealth): Promise<void> {
    // Store in time-series database for trending
    await this.metricsService.recordVendorHealth(vendorName, health);
  }
  
  private async triggerVendorAlert(vendorName: string, health: VendorHealth): Promise<void> {
    const alert = {
      type: 'vendor_health_degraded',
      vendor: vendorName,
      status: health.status,
      message: health.message,
      timestamp: health.timestamp,
      severity: health.status === 'error' ? 'critical' : 'warning'
    };
    
    await this.alertService.sendVendorAlert(alert);
  }
}
```

This comprehensive vendor integration strategy ensures reliable, scalable, and cost-effective partnerships while maintaining high service quality and business continuity.