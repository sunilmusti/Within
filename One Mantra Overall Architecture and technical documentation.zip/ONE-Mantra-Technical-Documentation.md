# ONE Mantra - Comprehensive Technical Documentation
**Enterprise-Grade Real Estate Platform**  
*Version 1.0 - October 2025*

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [System Architecture](#system-architecture)
3. [Data Models & Database Schema](#data-models--database-schema)
4. [API Specifications](#api-specifications)
5. [AI Gateway & Workflow Orchestration](#ai-gateway--workflow-orchestration)
6. [Frontend Architecture](#frontend-architecture)
7. [Middleware & Event Processing](#middleware--event-processing)
8. [Security & Compliance Framework](#security--compliance-framework)
9. [DevOps & Infrastructure](#devops--infrastructure)
10. [AIOps & Monitoring](#aiops--monitoring)
11. [Integration Specifications](#integration-specifications)
12. [Development Roadmap](#development-roadmap)

---

## Executive Summary

ONE Mantra is an end-to-end, AI-first real estate platform for Mantra Properties, covering the complete lifecycle from prospect enquiry to community living. Built on Claude Sonnet 4.5, it serves multiple personas through agentic workflows with enterprise-grade scalability supporting lakhs of users across hundreds of projects.

### Key Metrics
- **Target Users**: 500K+ concurrent users
- **Projects**: 100+ properties
- **Budget**: ≤₹3L/month total operational cost
- **Availability**: 99.9% SLA
- **Languages**: English, Hindi, Marathi + regional extensions

---

## System Architecture

### High-Level Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    Client Layer                              │
├─────────────────┬─────────────────┬─────────────────────────┤
│ React Native    │ React Web       │ IoT Devices             │
│ (Mobile Apps)   │ (Admin Portal)  │ (Security/Sensors)      │
└─────────────────┴─────────────────┴─────────────────────────┘
                           │
┌─────────────────────────────────────────────────────────────┐
│                   API Gateway                               │
│ - Authentication (OAuth 2.0/JWT)                          │
│ - Rate Limiting & Throttling                               │
│ - Request/Response Transformation                          │
│ - WAF & Security Policies                                  │
└─────────────────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────────────────┐
│                 Microservices Layer                         │
├──────────────┬──────────────┬──────────────┬───────────────┤
│ User Mgmt    │ Lead Mgmt    │ Property     │ Booking       │
│ Service      │ & AI Gateway │ Catalog      │ Service       │
├──────────────┼──────────────┼──────────────┼───────────────┤
│ Document     │ Society      │ Channel      │ Analytics     │
│ Management   │ Management   │ Partner Mgmt │ & Reporting   │
├──────────────┼──────────────┼──────────────┼───────────────┤
│ IoT          │ Referral &   │ Payment      │ Communication │
│ Integration  │ NRI Service  │ Gateway      │ Service       │
└──────────────┴──────────────┴──────────────┴───────────────┘
                           │
┌─────────────────────────────────────────────────────────────┐
│                  Event Bus (AWS SNS/SQS)                   │
│ - Lead Created/Updated     - Booking Confirmed             │
│ - Payment Processed        - Document Uploaded             │
│ - Visitor Checked In       - Maintenance Request           │
│ - SOS/Emergency Alert      - Commission Calculated         │
└─────────────────────────────────────────────────────────────┘
                           │
┌─────────────────────────────────────────────────────────────┐
│                    Data Layer                               │
├──────────────┬──────────────┬──────────────┬───────────────┤
│ PostgreSQL   │ MongoDB      │ Redis        │ AWS S3        │
│ (Core Data)  │ (Documents)  │ (Cache)      │ (Media/Files) │
├──────────────┴──────────────┴──────────────┴───────────────┤
│              Data Warehouse (Analytics)                    │
└─────────────────────────────────────────────────────────────┘
```

### Technology Stack

| Component | Technology | Purpose |
|-----------|------------|---------|
| **AI Core** | Claude Sonnet 4.5 (Amazon Bedrock) | Agentic workflows, chatbots, automation |
| **Mobile** | React Native | Cross-platform mobile apps |
| **Web** | React.js + Node.js | Admin dashboards, web portal |
| **Backend** | Node.js, Python | API services, AI gateway |
| **Databases** | PostgreSQL, MongoDB, Redis | Transactional, documents, caching |
| **Storage** | AWS S3, CloudFront CDN | Media, documents, VR tours |
| **Messaging** | AWS SNS/SQS, WebSockets | Event-driven architecture |
| **Container** | Docker, Kubernetes (EKS) | Microservices orchestration |
| **CI/CD** | GitHub Actions, Terraform | Automated deployment |
| **Monitoring** | Datadog, CloudWatch, Sentry | Observability and error tracking |
| **Security** | AWS KMS, IAM, WAF | Encryption, access control |

---

## Data Models & Database Schema

### Core Entities

#### 1. User Management
```sql
-- Users table (PostgreSQL)
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    role user_role_enum NOT NULL,
    profile_data JSONB,
    preferences JSONB,
    locale VARCHAR(10) DEFAULT 'en-IN',
    biometric_key_ref VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- User roles enumeration
CREATE TYPE user_role_enum AS ENUM (
    'prospect', 'channel_partner', 'resident', 'building_manager',
    'security_staff', 'maintenance_staff', 'admin', 'nri_buyer'
);
```

#### 2. Property & Units
```sql
-- Properties table
CREATE TABLE properties (
    property_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    location JSONB NOT NULL, -- {address, coordinates, city, state}
    project_tier project_tier_enum DEFAULT 'standard',
    amenities JSONB, -- Array of amenity objects
    vr_tour_urls JSONB, -- Array of VR tour links
    status property_status_enum DEFAULT 'upcoming',
    metadata JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE project_tier_enum AS ENUM ('standard', 'premium', 'luxury');
CREATE TYPE property_status_enum AS ENUM ('upcoming', 'under_construction', 'ready', 'completed');

-- Units table
CREATE TABLE units (
    unit_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID REFERENCES properties(property_id),
    unit_number VARCHAR(50) NOT NULL,
    floor_number INTEGER,
    unit_type VARCHAR(50), -- 1BHK, 2BHK, 3BHK, etc.
    carpet_area DECIMAL(10,2),
    built_up_area DECIMAL(10,2),
    base_price DECIMAL(15,2),
    current_price DECIMAL(15,2),
    status unit_status_enum DEFAULT 'available',
    amenities_included JSONB,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE unit_status_enum AS ENUM ('available', 'blocked', 'booked', 'sold', 'occupied');
```

#### 3. Lead Management
```sql
-- Leads table
CREATE TABLE leads (
    lead_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(user_id),
    source lead_source_enum NOT NULL,
    channel_partner_id UUID REFERENCES users(user_id),
    property_interests JSONB, -- Array of property_ids
    budget_range JSONB, -- {min: number, max: number}
    bant_score INTEGER CHECK (bant_score >= 0 AND bant_score <= 100),
    qualification_data JSONB,
    status lead_status_enum DEFAULT 'new',
    interaction_history JSONB,
    assigned_to UUID REFERENCES users(user_id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE lead_source_enum AS ENUM (
    'website', 'social_media', 'referral', 'channel_partner', 
    'advertisement', 'walk_in', 'nri_helpdesk'
);

CREATE TYPE lead_status_enum AS ENUM (
    'new', 'qualified', 'contacted', 'visit_scheduled', 
    'visited', 'eoi_submitted', 'converted', 'dropped'
);
```

#### 4. Booking & Transactions
```sql
-- Bookings table
CREATE TABLE bookings (
    booking_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lead_id UUID REFERENCES leads(lead_id),
    unit_id UUID REFERENCES units(unit_id),
    user_id UUID REFERENCES users(user_id),
    booking_amount DECIMAL(15,2) NOT NULL,
    total_amount DECIMAL(15,2) NOT NULL,
    payment_schedule JSONB, -- Array of payment milestones
    documents_uploaded JSONB, -- Array of document references
    status booking_status_enum DEFAULT 'initiated',
    agreement_signed_at TIMESTAMP,
    possession_date DATE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE booking_status_enum AS ENUM (
    'initiated', 'documents_pending', 'payment_pending', 
    'confirmed', 'possession_ready', 'completed', 'cancelled'
);

-- Transactions table
CREATE TABLE transactions (
    transaction_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES bookings(booking_id),
    user_id UUID REFERENCES users(user_id),
    amount DECIMAL(15,2) NOT NULL,
    transaction_type transaction_type_enum NOT NULL,
    payment_method VARCHAR(50),
    gateway_reference VARCHAR(255),
    status transaction_status_enum DEFAULT 'initiated',
    retry_count INTEGER DEFAULT 0,
    failure_reason TEXT,
    processed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE transaction_type_enum AS ENUM (
    'booking_amount', 'milestone_payment', 'maintenance_fee', 
    'amenity_charge', 'penalty', 'refund'
);

CREATE TYPE transaction_status_enum AS ENUM (
    'initiated', 'processing', 'completed', 'failed', 'refunded'
);
```

#### 5. Society Management
```sql
-- Maintenance requests table
CREATE TABLE maintenance_requests (
    request_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id UUID REFERENCES units(unit_id),
    resident_id UUID REFERENCES users(user_id),
    category maintenance_category_enum NOT NULL,
    priority priority_enum DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status maintenance_status_enum DEFAULT 'open',
    assigned_to UUID REFERENCES users(user_id),
    images JSONB, -- Array of image URLs
    estimated_cost DECIMAL(10,2),
    actual_cost DECIMAL(10,2),
    scheduled_date DATE,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE maintenance_category_enum AS ENUM (
    'plumbing', 'electrical', 'civil', 'painting', 'cleaning', 
    'security', 'gardening', 'common_area', 'elevator'
);

CREATE TYPE priority_enum AS ENUM ('low', 'medium', 'high', 'critical');

CREATE TYPE maintenance_status_enum AS ENUM (
    'open', 'assigned', 'in_progress', 'completed', 'closed', 'cancelled'
);

-- Visitor management table
CREATE TABLE visitor_entries (
    entry_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visitor_name VARCHAR(255) NOT NULL,
    visitor_phone VARCHAR(20),
    visitor_category visitor_category_enum NOT NULL,
    host_user_id UUID REFERENCES users(user_id),
    unit_id UUID REFERENCES units(unit_id),
    purpose TEXT,
    vehicle_number VARCHAR(20),
    photo_url VARCHAR(500),
    qr_code VARCHAR(255) UNIQUE,
    approved_by UUID REFERENCES users(user_id),
    check_in_time TIMESTAMP,
    check_out_time TIMESTAMP,
    status visitor_status_enum DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE visitor_category_enum AS ENUM (
    'family_friend', 'delivery', 'cab_driver', 'service_staff', 
    'vendor', 'guest', 'tenant', 'real_estate_agent'
);

CREATE TYPE visitor_status_enum AS ENUM (
    'pending', 'approved', 'checked_in', 'checked_out', 'expired', 'rejected'
);
```

#### 6. Commission & Referrals
```sql
-- Commission terms table
CREATE TABLE commission_terms (
    term_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    partner_id UUID REFERENCES users(user_id),
    property_id UUID REFERENCES properties(property_id),
    base_percentage DECIMAL(5,2) NOT NULL,
    tier_rates JSONB, -- Conditional rates based on performance
    clawback_rules JSONB,
    bonus_triggers JSONB,
    effective_from DATE NOT NULL,
    effective_until DATE,
    created_by UUID REFERENCES users(user_id),
    status commission_status_enum DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE commission_status_enum AS ENUM ('draft', 'active', 'expired', 'terminated');

-- Referrals table
CREATE TABLE referrals (
    referral_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    referrer_id UUID REFERENCES users(user_id),
    referee_phone VARCHAR(20) NOT NULL,
    referee_id UUID REFERENCES users(user_id),
    referral_code VARCHAR(50) UNIQUE NOT NULL,
    status referral_status_enum DEFAULT 'pending',
    points_earned INTEGER DEFAULT 0,
    reward_amount DECIMAL(10,2),
    conversion_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE referral_status_enum AS ENUM (
    'pending', 'registered', 'qualified', 'converted', 'rewarded'
);
```

#### 7. IoT & Events
```sql
-- IoT events table (MongoDB collection)
{
    "_id": ObjectId,
    "device_id": String,
    "device_type": String, // "smart_meter", "cctv", "access_control", "sensor"
    "property_id": String,
    "unit_id": String, // Optional for common area devices
    "event_type": String, // "reading", "alert", "motion", "door_open"
    "payload": Object,
    "timestamp": ISODate,
    "processed": Boolean,
    "created_at": ISODate
}

-- Blockchain records table
CREATE TABLE blockchain_records (
    record_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agreement_id VARCHAR(255) NOT NULL,
    document_hash VARCHAR(64) NOT NULL, -- SHA-256 hash
    parties_involved JSONB NOT NULL, -- Array of participant IDs
    agreement_type agreement_type_enum NOT NULL,
    effective_date DATE NOT NULL,
    blockchain_tx_hash VARCHAR(255),
    ledger_status ledger_status_enum DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TYPE agreement_type_enum AS ENUM (
    'booking_agreement', 'society_bylaws', 'vendor_contract', 
    'maintenance_agreement', 'grievance_resolution'
);

CREATE TYPE ledger_status_enum AS ENUM ('pending', 'confirmed', 'failed');
```

---

## API Specifications

### REST API Design Principles

1. **RESTful URLs**: Resource-based with proper HTTP methods
2. **Versioning**: `/api/v1/` prefix for all endpoints
3. **Authentication**: OAuth 2.0 with JWT tokens
4. **Rate Limiting**: Per-user and per-endpoint limits
5. **Error Handling**: Consistent error response format
6. **Pagination**: Cursor-based for large datasets

### Core API Endpoints

#### Authentication Service
```yaml
# OAuth 2.0 Authentication
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
POST /api/v1/auth/register
POST /api/v1/auth/verify-otp
POST /api/v1/auth/forgot-password
```

#### User Management Service
```yaml
GET /api/v1/users/profile
PUT /api/v1/users/profile
GET /api/v1/users/{user_id}
POST /api/v1/users/{user_id}/preferences
GET /api/v1/users/search?role={role}&property={property_id}
```

#### Lead Management Service
```yaml
POST /api/v1/leads                    # Create lead
GET /api/v1/leads                     # List leads with filters
GET /api/v1/leads/{lead_id}           # Get lead details
PUT /api/v1/leads/{lead_id}           # Update lead
POST /api/v1/leads/{lead_id}/qualify  # AI-driven qualification
POST /api/v1/leads/{lead_id}/assign   # Assign to partner/agent
GET /api/v1/leads/{lead_id}/interactions # Interaction history
POST /api/v1/leads/{lead_id}/interactions # Log interaction
```

#### Property Catalog Service
```yaml
GET /api/v1/properties                # List properties with filters
GET /api/v1/properties/{property_id}  # Property details
GET /api/v1/properties/{property_id}/units # Available units
GET /api/v1/properties/{property_id}/amenities # Amenity details
GET /api/v1/properties/{property_id}/vr-tours # VR tour links
GET /api/v1/properties/search?location={location}&budget={budget}
```

#### Booking Service
```yaml
POST /api/v1/bookings                 # Initiate booking
GET /api/v1/bookings                  # List user bookings
GET /api/v1/bookings/{booking_id}     # Booking details
PUT /api/v1/bookings/{booking_id}     # Update booking
POST /api/v1/bookings/{booking_id}/documents # Upload documents
POST /api/v1/bookings/{booking_id}/payments # Process payment
```

#### Society Management Service
```yaml
# Maintenance Requests
POST /api/v1/maintenance/requests
GET /api/v1/maintenance/requests
PUT /api/v1/maintenance/requests/{request_id}
POST /api/v1/maintenance/requests/{request_id}/assign

# Visitor Management
POST /api/v1/visitors/pre-approve
GET /api/v1/visitors
POST /api/v1/visitors/{entry_id}/check-in
POST /api/v1/visitors/{entry_id}/check-out
GET /api/v1/visitors/analytics

# Amenity Booking
GET /api/v1/amenities
POST /api/v1/amenities/{amenity_id}/book
GET /api/v1/amenities/bookings
DELETE /api/v1/amenities/bookings/{booking_id}
```

#### AI Gateway Service
```yaml
POST /api/v1/ai/chat                  # Chatbot interaction
POST /api/v1/ai/qualify-lead          # Lead qualification
POST /api/v1/ai/generate-response     # Context-aware responses
POST /api/v1/ai/analyze-sentiment     # Sentiment analysis
POST /api/v1/ai/summarize-case        # Grievance case summary
GET /api/v1/ai/prompts                # List prompt versions
PUT /api/v1/ai/prompts/{prompt_id}    # Update prompt (canary)
```

### API Response Format
```json
{
    "success": true,
    "data": {},
    "message": "Operation completed successfully",
    "meta": {
        "timestamp": "2025-10-15T17:30:00Z",
        "request_id": "req_12345",
        "version": "v1.0.0"
    },
    "pagination": {
        "total": 150,
        "page": 1,
        "per_page": 20,
        "has_next": true,
        "cursor": "eyJpZCI6IjEyMzQ1In0"
    }
}
```

### Error Response Format
```json
{
    "success": false,
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "Invalid input parameters",
        "details": [
            {
                "field": "email",
                "message": "Valid email address required"
            }
        ]
    },
    "meta": {
        "timestamp": "2025-10-15T17:30:00Z",
        "request_id": "req_12345"
    }
}
```

---

## AI Gateway & Workflow Orchestration

### Claude Sonnet 4.5 Integration Architecture

```python
# AI Gateway Service Structure
class AIGateway:
    def __init__(self):
        self.bedrock_client = boto3.client('bedrock-runtime')
        self.prompt_manager = PromptManager()
        self.context_manager = ContextManager()
        self.workflow_orchestrator = WorkflowOrchestrator()

    async def process_conversation(self, user_id: str, message: str, 
                                 context: dict) -> AIResponse:
        # Load user context and conversation history
        conversation_context = await self.context_manager.get_context(user_id)
        
        # Select appropriate prompt template
        prompt_template = await self.prompt_manager.get_prompt(
            user_role=context.get('role'),
            workflow_stage=context.get('stage')
        )
        
        # Prepare Claude Sonnet 4.5 request
        prompt = await self.prepare_prompt(
            template=prompt_template,
            user_message=message,
            context=conversation_context
        )
        
        # Call Claude Sonnet 4.5
        response = await self.call_claude(prompt)
        
        # Process response and trigger workflows
        processed_response = await self.process_response(response, context)
        
        # Update context and trigger events
        await self.context_manager.update_context(user_id, processed_response)
        await self.workflow_orchestrator.trigger_workflows(processed_response)
        
        return processed_response

    async def call_claude(self, prompt: str) -> str:
        try:
            response = self.bedrock_client.invoke_model(
                modelId='anthropic.claude-3-5-sonnet-20240620-v1:0',
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 4000,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                })
            )
            
            result = json.loads(response['body'].read())
            return result['content'][0]['text']
            
        except Exception as e:
            logger.error(f"Claude API call failed: {str(e)}")
            return await self.get_fallback_response()
```

### Agentic Workflow Definitions

#### 1. Lead Qualification Workflow
```python
class LeadQualificationAgent:
    def __init__(self, ai_gateway: AIGateway):
        self.ai_gateway = ai_gateway
        self.crm_service = CRMService()
        
    async def qualify_lead(self, lead_id: str, conversation_data: dict) -> QualificationResult:
        # Extract BANT criteria using Claude
        bant_analysis = await self.ai_gateway.analyze_bant(conversation_data)
        
        # Calculate lead score
        lead_score = await self.calculate_lead_score(bant_analysis)
        
        # Generate next best actions
        next_actions = await self.ai_gateway.suggest_next_actions(
            lead_score=lead_score,
            conversation_history=conversation_data
        )
        
        # Update lead in CRM
        await self.crm_service.update_lead_qualification(
            lead_id=lead_id,
            score=lead_score,
            bant_data=bant_analysis,
            next_actions=next_actions
        )
        
        # Trigger appropriate workflow
        if lead_score >= 80:
            await self.trigger_hot_lead_workflow(lead_id)
        elif lead_score >= 50:
            await self.trigger_warm_lead_workflow(lead_id)
        else:
            await self.trigger_nurture_workflow(lead_id)
            
        return QualificationResult(
            lead_id=lead_id,
            score=lead_score,
            qualification=bant_analysis,
            next_actions=next_actions
        )
```

#### 2. Site Visit Coordination Agent
```python
class SiteVisitAgent:
    async def coordinate_visit(self, lead_id: str, visit_request: dict) -> VisitCoordination:
        # Check availability and suggest slots
        available_slots = await self.property_service.get_available_slots(
            property_id=visit_request['property_id'],
            date_range=visit_request['preferred_dates']
        )
        
        # AI-powered slot recommendation
        recommended_slot = await self.ai_gateway.recommend_visit_slot(
            lead_profile=await self.lead_service.get_lead_profile(lead_id),
            available_slots=available_slots,
            weather_data=await self.weather_service.get_forecast()
        )
        
        # Book the slot
        visit_id = await self.calendar_service.book_slot(
            lead_id=lead_id,
            slot=recommended_slot
        )
        
        # Generate visit brief for sales team
        visit_brief = await self.ai_gateway.generate_visit_brief(
            lead_id=lead_id,
            property_id=visit_request['property_id']
        )
        
        # Schedule automated reminders
        await self.notification_service.schedule_reminders(
            visit_id=visit_id,
            lead_contact=visit_request['contact_info']
        )
        
        return VisitCoordination(
            visit_id=visit_id,
            scheduled_slot=recommended_slot,
            visit_brief=visit_brief,
            confirmation_sent=True
        )
```

### Prompt Management System

```python
class PromptManager:
    def __init__(self):
        self.prompt_versions = {}
        self.active_prompts = {}
        self.canary_deployments = {}
        
    async def get_prompt(self, user_role: str, workflow_stage: str) -> str:
        prompt_key = f"{user_role}_{workflow_stage}"
        
        # Check if user is in canary group
        if await self.is_canary_user(user_role):
            canary_prompt = self.canary_deployments.get(prompt_key)
            if canary_prompt:
                await self.track_canary_usage(prompt_key, canary_prompt['version'])
                return canary_prompt['content']
        
        # Return stable prompt
        active_prompt = self.active_prompts.get(prompt_key)
        return active_prompt['content'] if active_prompt else self.get_default_prompt(prompt_key)
    
    async def deploy_canary_prompt(self, prompt_key: str, new_content: str, 
                                 canary_percentage: float = 5.0) -> str:
        version_id = f"v{int(time.time())}"
        
        self.canary_deployments[prompt_key] = {
            'content': new_content,
            'version': version_id,
            'percentage': canary_percentage,
            'deployed_at': datetime.utcnow(),
            'metrics': {
                'usage_count': 0,
                'success_rate': 0.0,
                'avg_response_time': 0.0,
                'user_satisfaction': 0.0
            }
        }
        
        # Schedule monitoring and evaluation
        await self.schedule_canary_evaluation(prompt_key, version_id)
        
        return version_id
```

---

## Frontend Architecture

### React Native Mobile App Structure

```
src/
├── components/           # Reusable UI components
│   ├── common/          # Generic components (Button, Input, Card)
│   ├── forms/           # Form-specific components
│   ├── chat/            # AI chatbot components
│   └── media/           # VR/Image viewers
├── screens/             # Screen components by feature
│   ├── auth/            # Login, Registration, OTP
│   ├── property/        # Property listing, details, VR tours
│   ├── booking/         # EOI, Payment, Documents
│   ├── society/         # Dashboard, Maintenance, Visitors
│   ├── partner/         # Channel partner flows
│   └── referral/        # NRI and referral programs
├── navigation/          # Navigation configuration
│   ├── AppNavigator.tsx # Main app navigation
│   ├── AuthNavigator.tsx# Authentication flow
│   └── TabNavigator.tsx # Bottom tab navigation
├── services/            # API and external service calls
│   ├── api/             # REST API clients
│   ├── auth/            # Authentication service
│   ├── storage/         # Local storage management
│   └── notifications/   # Push notification handling
├── state/               # State management (Redux Toolkit)
│   ├── slices/          # Redux slices by feature
│   ├── middleware/      # Custom middleware
│   └── store.ts         # Store configuration
├── utils/               # Utility functions
│   ├── constants/       # App constants
│   ├── helpers/         # Helper functions
│   └── validation/      # Form validation schemas
├── assets/              # Static assets
│   ├── images/          # Image assets
│   ├── icons/           # Icon assets
│   └── fonts/           # Custom fonts
└── styles/              # Styling
    ├── colors.ts        # Color palette
    ├── typography.ts    # Typography styles
    └── dimensions.ts    # Spacing and dimensions
```

### React Web Admin Portal Structure

```
src/
├── components/
│   ├── dashboard/       # Dashboard widgets
│   ├── tables/          # Data tables with sorting/filtering
│   ├── forms/           # Admin forms
│   ├── charts/          # Analytics charts
│   └── modals/          # Modal components
├── pages/
│   ├── Dashboard.tsx    # Main dashboard
│   ├── Properties/      # Property management
│   ├── Leads/           # Lead management
│   ├── Users/           # User management
│   ├── Analytics/       # Reporting and analytics
│   ├── Settings/        # System configuration
│   └── AIOperations/    # AI prompt management
├── hooks/               # Custom React hooks
│   ├── useApi.ts        # API interaction hook
│   ├── useAuth.ts       # Authentication hook
│   └── useWebSocket.ts  # WebSocket connection
├── context/             # React context providers
│   ├── AuthContext.tsx  # Authentication context
│   └── ThemeContext.tsx # Theme provider
└── layouts/             # Page layouts
    ├── MainLayout.tsx   # Main app layout
    └── AuthLayout.tsx   # Authentication layout
```

### Key Frontend Components

#### AI Chatbot Component
```typescript
// components/chat/AIChatbot.tsx
interface ChatbotProps {
    userId: string;
    context: ChatContext;
    onLeadGenerated?: (leadId: string) => void;
}

export const AIChatbot: React.FC<ChatbotProps> = ({ 
    userId, 
    context, 
    onLeadGenerated 
}) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isTyping, setIsTyping] = useState(false);
    const [sessionId, setSessionId] = useState<string>();

    const sendMessage = async (content: string) => {
        const userMessage = { 
            id: uuidv4(), 
            content, 
            sender: 'user', 
            timestamp: new Date() 
        };
        
        setMessages(prev => [...prev, userMessage]);
        setIsTyping(true);

        try {
            const response = await aiService.sendMessage({
                sessionId,
                message: content,
                userId,
                context
            });

            const aiMessage = {
                id: response.messageId,
                content: response.content,
                sender: 'ai',
                timestamp: new Date(),
                actions: response.suggestedActions,
                leadData: response.leadData
            };

            setMessages(prev => [...prev, aiMessage]);
            
            // Handle lead generation
            if (response.leadData && onLeadGenerated) {
                onLeadGenerated(response.leadData.leadId);
            }
        } catch (error) {
            console.error('Chat error:', error);
            // Handle error with fallback message
        } finally {
            setIsTyping(false);
        }
    };

    return (
        <View style={styles.chatContainer}>
            <MessageList 
                messages={messages} 
                isTyping={isTyping} 
            />
            <MessageInput 
                onSend={sendMessage} 
                placeholder={getLocalizedText('chat.placeholder')} 
            />
        </View>
    );
};
```

#### Property Card Component
```typescript
// components/property/PropertyCard.tsx
interface PropertyCardProps {
    property: Property;
    onViewDetails: (propertyId: string) => void;
    onStartVRTour: (vrUrl: string) => void;
    showPricing: boolean;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({
    property,
    onViewDetails,
    onStartVRTour,
    showPricing
}) => {
    const { colors } = useTheme();
    const { t } = useTranslation();

    return (
        <TouchableOpacity
            style={[styles.card, { borderColor: colors.border }]}
            onPress={() => onViewDetails(property.property_id)}
            activeOpacity={0.8}
        >
            <ImageCarousel 
                images={property.images} 
                style={styles.imageCarousel}
            />
            
            <View style={styles.content}>
                <Text style={[styles.title, { color: colors.text }]}>
                    {property.name}
                </Text>
                
                <Text style={[styles.location, { color: colors.textSecondary }]}>
                    📍 {property.location.area}, {property.location.city}
                </Text>
                
                {showPricing && (
                    <Text style={[styles.price, { color: colors.primary }]}>
                        {t('common.starting_from')} ₹{formatPrice(property.starting_price)}
                    </Text>
                )}
                
                <View style={styles.amenities}>
                    {property.amenities.slice(0, 3).map((amenity, index) => (
                        <Chip 
                            key={index} 
                            text={amenity} 
                            style={styles.amenityChip} 
                        />
                    ))}
                </View>
                
                <View style={styles.actions}>
                    <Button
                        title={t('property.view_details')}
                        variant="outline"
                        size="small"
                        onPress={() => onViewDetails(property.property_id)}
                    />
                    
                    {property.vr_tour_urls.length > 0 && (
                        <Button
                            title={t('property.vr_tour')}
                            variant="primary"
                            size="small"
                            icon="vr-cardboard"
                            onPress={() => onStartVRTour(property.vr_tour_urls[0])}
                        />
                    )}
                </View>
            </View>
        </TouchableOpacity>
    );
};
```

---

## Middleware & Event Processing

### Event-Driven Architecture

```typescript
// Event definitions
interface BaseEvent {
    eventId: string;
    eventType: string;
    timestamp: Date;
    source: string;
    version: string;
    data: Record<string, any>;
}

interface LeadCreatedEvent extends BaseEvent {
    eventType: 'LEAD_CREATED';
    data: {
        leadId: string;
        userId: string;
        source: string;
        initialData: any;
    };
}

interface BookingConfirmedEvent extends BaseEvent {
    eventType: 'BOOKING_CONFIRMED';
    data: {
        bookingId: string;
        unitId: string;
        userId: string;
        amount: number;
    };
}

// Event processor
class EventProcessor {
    private handlers: Map<string, EventHandler[]> = new Map();
    
    constructor(
        private messageQueue: MessageQueue,
        private eventStore: EventStore
    ) {}
    
    async processEvent(event: BaseEvent): Promise<void> {
        // Store event
        await this.eventStore.store(event);
        
        // Get handlers for event type
        const handlers = this.handlers.get(event.eventType) || [];
        
        // Process handlers in parallel
        const promises = handlers.map(handler => 
            this.executeHandler(handler, event)
        );
        
        await Promise.allSettled(promises);
    }
    
    private async executeHandler(
        handler: EventHandler, 
        event: BaseEvent
    ): Promise<void> {
        try {
            await handler.handle(event);
        } catch (error) {
            console.error(`Handler ${handler.name} failed:`, error);
            
            // Retry mechanism
            if (handler.retryable) {
                await this.scheduleRetry(handler, event);
            }
        }
    }
    
    registerHandler(eventType: string, handler: EventHandler): void {
        if (!this.handlers.has(eventType)) {
            this.handlers.set(eventType, []);
        }
        this.handlers.get(eventType)!.push(handler);
    }
}

// Example event handlers
class LeadCreatedHandler implements EventHandler {
    name = 'LeadCreatedHandler';
    retryable = true;
    
    async handle(event: LeadCreatedEvent): Promise<void> {
        // Send welcome message
        await this.notificationService.sendWelcomeMessage(
            event.data.userId,
            event.data.leadId
        );
        
        // Trigger AI qualification
        await this.aiGateway.startQualificationWorkflow(
            event.data.leadId
        );
        
        // Update analytics
        await this.analyticsService.trackLeadCreation(event.data);
        
        // Sync with CRM
        await this.crmService.createLead(event.data);
    }
}

class BookingConfirmedHandler implements EventHandler {
    name = 'BookingConfirmedHandler';
    retryable = true;
    
    async handle(event: BookingConfirmedEvent): Promise<void> {
        // Update unit status
        await this.propertyService.markUnitAsBooked(event.data.unitId);
        
        // Calculate channel partner commission
        await this.commissionService.calculateCommission(
            event.data.bookingId
        );
        
        // Send confirmation notifications
        await this.notificationService.sendBookingConfirmation(
            event.data.userId,
            event.data.bookingId
        );
        
        // Start document collection workflow
        await this.documentService.initiateCollection(
            event.data.bookingId
        );
        
        // Update blockchain record
        await this.blockchainService.recordTransaction(event.data);
    }
}
```

### Message Queue Configuration

```yaml
# AWS SNS/SQS Configuration
Topics:
  - Name: lead-events
    EventTypes:
      - LEAD_CREATED
      - LEAD_QUALIFIED
      - LEAD_ASSIGNED
      - LEAD_CONVERTED
    
  - Name: booking-events
    EventTypes:
      - BOOKING_INITIATED
      - BOOKING_CONFIRMED
      - PAYMENT_PROCESSED
      - DOCUMENTS_UPLOADED
      
  - Name: society-events
    EventTypes:
      - MAINTENANCE_REQUEST_CREATED
      - VISITOR_CHECKED_IN
      - AMENITY_BOOKED
      - SOS_ALERT_TRIGGERED

Queues:
  - Name: lead-processing-queue
    DeadLetterQueue: lead-dlq
    VisibilityTimeout: 300
    MaxRetries: 3
    
  - Name: notification-queue
    DeadLetterQueue: notification-dlq
    VisibilityTimeout: 60
    MaxRetries: 5
    
  - Name: crm-sync-queue
    DeadLetterQueue: crm-sync-dlq
    VisibilityTimeout: 600
    MaxRetries: 3
```

---

## Security & Compliance Framework

### Authentication & Authorization

```typescript
// JWT Token Structure
interface JWTPayload {
    sub: string;        // User ID
    email: string;      // User email
    role: UserRole;     // User role
    permissions: string[]; // Granular permissions
    exp: number;        // Expiration timestamp
    iat: number;        // Issued at timestamp
    jti: string;        // JWT ID for revocation
    property_access?: string[]; // Property-specific access
}

// RBAC Implementation
class RoleBasedAccessControl {
    private permissions: Map<UserRole, Permission[]> = new Map([
        ['prospect', [
            'property:read',
            'lead:create',
            'lead:update_own',
            'booking:create_own',
            'referral:create'
        ]],
        ['channel_partner', [
            'lead:create',
            'lead:read_assigned',
            'lead:update_assigned',
            'commission:read_own',
            'property:read'
        ]],
        ['resident', [
            'society:read',
            'maintenance:create',
            'visitor:manage_own',
            'amenity:book',
            'document:read_own'
        ]],
        ['building_manager', [
            'society:manage',
            'maintenance:assign',
            'visitor:manage_all',
            'user:read_residents',
            'analytics:read_property'
        ]],
        ['admin', ['*']] // All permissions
    ]);

    hasPermission(userRole: UserRole, permission: string): boolean {
        const rolePermissions = this.permissions.get(userRole) || [];
        return rolePermissions.includes('*') || 
               rolePermissions.includes(permission);
    }

    checkPropertyAccess(user: AuthUser, propertyId: string): boolean {
        // Admin has access to all properties
        if (user.role === 'admin') return true;
        
        // Check if user has specific property access
        return user.property_access?.includes(propertyId) || false;
    }
}

// Middleware for API protection
class AuthMiddleware {
    async authenticate(req: Request, res: Response, next: NextFunction) {
        try {
            const token = this.extractToken(req);
            const decoded = jwt.verify(token, process.env.JWT_SECRET) as JWTPayload;
            
            // Check if token is revoked
            if (await this.isTokenRevoked(decoded.jti)) {
                throw new Error('Token revoked');
            }
            
            req.user = {
                id: decoded.sub,
                email: decoded.email,
                role: decoded.role,
                permissions: decoded.permissions,
                property_access: decoded.property_access
            };
            
            next();
        } catch (error) {
            res.status(401).json({ error: 'Unauthorized' });
        }
    }
    
    authorize(permission: string) {
        return (req: Request, res: Response, next: NextFunction) => {
            if (!this.rbac.hasPermission(req.user.role, permission)) {
                return res.status(403).json({ error: 'Forbidden' });
            }
            next();
        };
    }
}
```

### Data Encryption

```typescript
// Encryption service for sensitive data
class EncryptionService {
    private kmsClient = new AWS.KMS();
    
    async encryptSensitiveData(data: any, dataType: DataType): Promise<string> {
        const dataKey = await this.getDataEncryptionKey(dataType);
        const cipher = crypto.createCipher('aes-256-gcm', dataKey);
        
        let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
        encrypted += cipher.final('hex');
        
        const authTag = cipher.getAuthTag();
        
        return `${encrypted}:${authTag.toString('hex')}`;
    }
    
    async decryptSensitiveData(encryptedData: string, dataType: DataType): Promise<any> {
        const [encrypted, authTag] = encryptedData.split(':');
        const dataKey = await this.getDataEncryptionKey(dataType);
        
        const decipher = crypto.createDecipher('aes-256-gcm', dataKey);
        decipher.setAuthTag(Buffer.from(authTag, 'hex'));
        
        let decrypted = decipher.update(encrypted, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        
        return JSON.parse(decrypted);
    }
    
    private async getDataEncryptionKey(dataType: DataType): Promise<string> {
        const params = {
            KeyId: process.env.KMS_KEY_ID,
            DataKeySpec: 'AES_256',
            EncryptionContext: { dataType }
        };
        
        const result = await this.kmsClient.generateDataKey(params).promise();
        return result.Plaintext.toString('base64');
    }
}

// Biometric authentication for mobile
class BiometricAuth {
    async setupBiometric(userId: string): Promise<void> {
        const { isAvailable, biometryType } = await TouchID.isSupported();
        
        if (!isAvailable) {
            throw new Error('Biometric authentication not available');
        }
        
        // Generate key pair for biometric authentication
        const keyPair = await this.generateKeyPair();
        
        // Store public key on server
        await this.userService.storeBiometricPublicKey(
            userId, 
            keyPair.publicKey
        );
        
        // Store private key in device secure enclave
        await SecureStore.setItemAsync(
            `biometric_key_${userId}`,
            keyPair.privateKey,
            { requireAuthentication: true }
        );
    }
    
    async authenticateWithBiometric(userId: string): Promise<string> {
        try {
            await TouchID.authenticate('Authenticate to access your account');
            
            // Retrieve private key from secure enclave
            const privateKey = await SecureStore.getItemAsync(
                `biometric_key_${userId}`,
                { requireAuthentication: true }
            );
            
            // Generate authentication token
            const challenge = await this.getAuthChallenge(userId);
            const signature = this.signChallenge(challenge, privateKey);
            
            // Verify with server
            const token = await this.authService.verifyBiometricAuth(
                userId, 
                challenge, 
                signature
            );
            
            return token;
        } catch (error) {
            throw new Error('Biometric authentication failed');
        }
    }
}
```

### Compliance Implementation

```typescript
// GDPR/Data Protection compliance
class DataProtectionService {
    async handleDataRequest(userId: string, requestType: DataRequestType): Promise<void> {
        switch (requestType) {
            case 'ACCESS':
                await this.handleAccessRequest(userId);
                break;
            case 'DELETE':
                await this.handleDeletionRequest(userId);
                break;
            case 'PORTABILITY':
                await this.handlePortabilityRequest(userId);
                break;
            case 'RECTIFICATION':
                await this.handleRectificationRequest(userId);
                break;
        }
    }
    
    private async handleDeletionRequest(userId: string): Promise<void> {
        // Get all user data
        const userData = await this.getAllUserData(userId);
        
        // Check for legal retention requirements
        const retentionChecks = await this.checkRetentionRequirements(userData);
        
        // Anonymize data that cannot be deleted
        for (const check of retentionChecks) {
            if (check.mustRetain) {
                await this.anonymizeData(check.dataType, userId);
            } else {
                await this.deleteData(check.dataType, userId);
            }
        }
        
        // Log deletion request compliance
        await this.auditService.logDataDeletion(userId, retentionChecks);
    }
    
    private async handleAccessRequest(userId: string): Promise<void> {
        const userData = await this.getAllUserData(userId);
        const exportData = await this.formatForExport(userData);
        
        // Send secure download link
        await this.notificationService.sendDataExportLink(userId, exportData);
    }
}

// RERA compliance
class RERACompliance {
    async validateProjectListing(property: Property): Promise<ValidationResult> {
        const validations = [
            this.validateRERARegistration(property),
            this.validateCarpetAreaDeclaration(property),
            this.validatePaymentSchedule(property),
            this.validatePossessionTimeline(property)
        ];
        
        const results = await Promise.all(validations);
        return this.aggregateValidationResults(results);
    }
    
    private async validateRERARegistration(property: Property): Promise<boolean> {
        if (!property.rera_number) {
            throw new Error('RERA registration number is mandatory');
        }
        
        // Verify RERA number with government database
        const isValid = await this.reraService.verifyRegistration(
            property.rera_number,
            property.location.state
        );
        
        return isValid;
    }
    
    private async validateCarpetAreaDeclaration(property: Property): Promise<boolean> {
        // Ensure carpet area is clearly mentioned and complies with RERA norms
        for (const unit of property.units) {
            if (!unit.carpet_area || unit.carpet_area <= 0) {
                throw new Error(`Carpet area not specified for unit ${unit.unit_number}`);
            }
            
            // Carpet area should be at least 70% of built-up area
            const ratio = unit.carpet_area / unit.built_up_area;
            if (ratio < 0.7) {
                console.warn(`Low carpet area ratio for unit ${unit.unit_number}: ${ratio}`);
            }
        }
        
        return true;
    }
}
```

---

## DevOps & Infrastructure

### Kubernetes Deployment Configuration

```yaml
# deployment/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: one-mantra
  labels:
    name: one-mantra
    environment: production

---
# deployment/api-gateway.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-gateway
  namespace: one-mantra
spec:
  replicas: 3
  selector:
    matchLabels:
      app: api-gateway
  template:
    metadata:
      labels:
        app: api-gateway
    spec:
      containers:
      - name: api-gateway
        image: one-mantra/api-gateway:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: jwt-secret
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: database-secrets
              key: postgres-url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 60
          periodSeconds: 30

---
# deployment/services.yaml
apiVersion: v1
kind: Service
metadata:
  name: api-gateway-service
  namespace: one-mantra
spec:
  selector:
    app: api-gateway
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
  type: ClusterIP

---
# deployment/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: one-mantra-ingress
  namespace: one-mantra
  annotations:
    kubernetes.io/ingress.class: "nginx"
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  tls:
  - hosts:
    - api.onemantra.com
    secretName: onemantra-tls
  rules:
  - host: api.onemantra.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api-gateway-service
            port:
              number: 80
```

### CI/CD Pipeline Configuration

```yaml
# .github/workflows/deploy.yml
name: Build and Deploy

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

env:
  AWS_REGION: ap-south-1
  ECR_REPOSITORY: one-mantra
  EKS_CLUSTER_NAME: one-mantra-cluster

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Run tests
      run: npm run test:coverage
    
    - name: Run linting
      run: npm run lint
    
    - name: Run security audit
      run: npm audit --audit-level moderate

  build-and-push:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: ${{ env.AWS_REGION }}
    
    - name: Login to Amazon ECR
      id: login-ecr
      uses: aws-actions/amazon-ecr-login@v1
    
    - name: Build and tag Docker image
      env:
        ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
        IMAGE_TAG: ${{ github.sha }}
      run: |
        docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .
        docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:latest .
    
    - name: Push image to Amazon ECR
      env:
        ECR_REGISTRY: ${{ steps.login-ecr.outputs.registry }}
        IMAGE_TAG: ${{ github.sha }}
      run: |
        docker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG
        docker push $ECR_REGISTRY/$ECR_REPOSITORY:latest

  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: ${{ env.AWS_REGION }}
    
    - name: Update kube config
      run: aws eks update-kubeconfig --name $EKS_CLUSTER_NAME --region $AWS_REGION
    
    - name: Deploy to EKS
      env:
        IMAGE_TAG: ${{ github.sha }}
      run: |
        sed -i.bak "s|DOCKER_IMAGE|$ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG|g" deployment/api-gateway.yaml
        kubectl apply -f deployment/
        kubectl rollout status deployment/api-gateway -n one-mantra
```

### Infrastructure as Code (Terraform)

```hcl
# infrastructure/main.tf
terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  
  backend "s3" {
    bucket = "one-mantra-terraform-state"
    key    = "infrastructure/terraform.tfstate"
    region = "ap-south-1"
  }
}

provider "aws" {
  region = var.aws_region
}

# EKS Cluster
module "eks" {
  source = "terraform-aws-modules/eks/aws"
  
  cluster_name    = var.cluster_name
  cluster_version = "1.27"
  
  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets
  
  node_groups = {
    main = {
      desired_capacity = 3
      max_capacity     = 10
      min_capacity     = 3
      
      instance_types = ["t3.large"]
      
      k8s_labels = {
        Environment = var.environment
        Application = "one-mantra"
      }
    }
  }
}

# RDS PostgreSQL
resource "aws_db_instance" "main" {
  identifier = "one-mantra-db"
  
  engine         = "postgres"
  engine_version = "15.3"
  instance_class = "db.t3.large"
  
  allocated_storage     = 100
  max_allocated_storage = 1000
  storage_encrypted     = true
  
  db_name  = "onemantra"
  username = var.db_username
  password = var.db_password
  
  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.main.name
  
  backup_retention_period = 30
  backup_window          = "03:00-04:00"
  maintenance_window     = "sun:04:00-sun:05:00"
  
  skip_final_snapshot = false
  final_snapshot_identifier = "one-mantra-final-snapshot"
  
  tags = {
    Name        = "one-mantra-db"
    Environment = var.environment
  }
}

# ElastiCache Redis
resource "aws_elasticache_subnet_group" "main" {
  name       = "one-mantra-cache-subnet"
  subnet_ids = module.vpc.private_subnets
}

resource "aws_elasticache_replication_group" "main" {
  replication_group_id         = "one-mantra-redis"
  description                  = "Redis cluster for ONE Mantra"
  
  port               = 6379
  parameter_group_name = "default.redis7"
  node_type          = "cache.t3.medium"
  
  num_cache_clusters = 3
  
  subnet_group_name  = aws_elasticache_subnet_group.main.name
  security_group_ids = [aws_security_group.redis.id]
  
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  
  tags = {
    Name        = "one-mantra-redis"
    Environment = var.environment
  }
}

# S3 Buckets
resource "aws_s3_bucket" "media" {
  bucket = "one-mantra-media-${var.environment}"
  
  tags = {
    Name        = "ONE Mantra Media Storage"
    Environment = var.environment
  }
}

resource "aws_s3_bucket_versioning" "media" {
  bucket = aws_s3_bucket.media.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_encryption" "media" {
  bucket = aws_s3_bucket.media.id
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default {
        sse_algorithm = "AES256"
      }
    }
  }
}
```

---

## AIOps & Monitoring

### Monitoring Dashboard Configuration

```typescript
// monitoring/dashboards/aiops-dashboard.ts
export const AIOpsConfiguration = {
    dashboards: {
        overview: {
            title: "ONE Mantra - AI Operations Overview",
            widgets: [
                {
                    type: "metric",
                    title: "Error Budget Burn Rate",
                    query: "rate(http_requests_total{status=~'5..'}[5m]) / rate(http_requests_total[5m])",
                    thresholds: {
                        critical: 0.02, // 2% error rate
                        warning: 0.01   // 1% error rate
                    }
                },
                {
                    type: "metric",
                    title: "AI Response Latency P95",
                    query: "histogram_quantile(0.95, rate(ai_response_duration_seconds_bucket[5m]))",
                    thresholds: {
                        critical: 0.5,  // 500ms
                        warning: 0.3    // 300ms
                    }
                },
                {
                    type: "metric",
                    title: "Lead Qualification Accuracy",
                    query: "ai_lead_qualification_accuracy_ratio",
                    thresholds: {
                        critical: 0.8,  // 80% accuracy
                        warning: 0.85   // 85% accuracy
                    }
                },
                {
                    type: "graph",
                    title: "AI Agent Handoff Rate",
                    query: "rate(ai_agent_handoffs_total[5m])",
                    target: 0.05 // Target 5% handoff rate
                }
            ]
        },
        
        userExperience: {
            title: "User Experience Metrics",
            widgets: [
                {
                    type: "metric",
                    title: "Customer Satisfaction (CSAT)",
                    query: "avg(csat_score)",
                    thresholds: {
                        critical: 4.0,
                        warning: 4.2
                    }
                },
                {
                    type: "metric", 
                    title: "Self-Service Success Rate",
                    query: "rate(self_service_completions_total[1h]) / rate(user_sessions_total[1h])",
                    thresholds: {
                        critical: 0.6,  // 60%
                        warning: 0.7    // 70%
                    }
                },
                {
                    type: "heatmap",
                    title: "Response Time Distribution",
                    query: "api_request_duration_seconds_bucket"
                }
            ]
        }
    },
    
    alerting: {
        rules: [
            {
                name: "HighErrorBudgetBurn",
                condition: "rate(http_requests_total{status=~'5..'}[1h]) / rate(http_requests_total[1h]) > 0.02",
                duration: "5m",
                severity: "critical",
                annotations: {
                    summary: "High error budget burn rate detected",
                    description: "Error rate is {{ $value | humanizePercentage }} which will exhaust monthly error budget in less than 2 days"
                },
                actions: ["page_oncall", "create_incident"]
            },
            {
                name: "AIAgentHighLatency", 
                condition: "histogram_quantile(0.95, rate(ai_response_duration_seconds_bucket[5m])) > 0.5",
                duration: "10m",
                severity: "warning",
                annotations: {
                    summary: "AI agent response latency is high",
                    description: "95th percentile latency is {{ $value }}s"
                },
                actions: ["slack_alert"]
            },
            {
                name: "LeadQualificationAccuracyDrop",
                condition: "ai_lead_qualification_accuracy_ratio < 0.8",
                duration: "15m", 
                severity: "warning",
                annotations: {
                    summary: "AI lead qualification accuracy dropped",
                    description: "Accuracy dropped to {{ $value | humanizePercentage }}"
                },
                actions: ["slack_alert", "trigger_model_review"]
            }
        ]
    }
};

// AIOps runbook procedures
class AIOpsRunbook {
    static procedures = {
        highErrorBudgetBurn: {
            title: "High Error Budget Burn Rate",
            steps: [
                "1. Check service health dashboard for failing components",
                "2. Verify if there's an ongoing deployment",
                "3. Check database connection pool and query performance",
                "4. Review recent AI model changes or prompt updates",
                "5. If infrastructure issue, scale resources or failover",
                "6. If AI-related, rollback to previous stable prompt version",
                "7. Create incident ticket with timeline and impact assessment"
            ],
            escalation: "If not resolved in 15 minutes, page engineering manager"
        },
        
        aiModelDegradation: {
            title: "AI Model Performance Degradation", 
            steps: [
                "1. Check canary deployment status - is new prompt version causing issues?",
                "2. Compare current metrics vs historical baselines",
                "3. Check Claude Sonnet 4.5 API status and rate limits",
                "4. Review recent training data changes or model updates",
                "5. Roll back to previous prompt version if necessary",
                "6. Increase human agent capacity temporarily",
                "7. Schedule model retraining or prompt optimization review"
            ],
            escalation: "Notify AI/ML team lead if accuracy drops below 75%"
        },
        
        databasePerformanceIssue: {
            title: "Database Performance Degradation",
            steps: [
                "1. Check database CPU, memory, and connection pool metrics",
                "2. Identify slow queries from performance insights",
                "3. Check for blocking locks or deadlocks", 
                "4. Review recent schema changes or index modifications",
                "5. Scale read replicas if read-heavy workload",
                "6. Optimize or kill problematic queries",
                "7. Consider vertical scaling if resource constraints"
            ],
            escalation: "Page database admin if unable to resolve in 20 minutes"
        }
    };
    
    static getRunbook(alertName: string): RunbookProcedure {
        const mapping = {
            'HighErrorBudgetBurn': this.procedures.highErrorBudgetBurn,
            'AIAgentHighLatency': this.procedures.aiModelDegradation,
            'LeadQualificationAccuracyDrop': this.procedures.aiModelDegradation,
            'DatabaseSlowQueries': this.procedures.databasePerformanceIssue
        };
        
        return mapping[alertName] || this.procedures.genericIncident;
    }
}
```

### Canary Deployment for AI Prompts

```typescript
// ai/prompt-deployment.ts
class CanaryPromptDeployment {
    private readonly CANARY_PERCENTAGE = 5; // Start with 5% traffic
    private readonly EVALUATION_DURATION = 24 * 60 * 60 * 1000; // 24 hours
    
    async deployCanaryPrompt(
        promptKey: string, 
        newContent: string, 
        metadata: PromptMetadata
    ): Promise<DeploymentResult> {
        const deploymentId = `canary_${Date.now()}`;
        
        // Store canary prompt version
        await this.promptStore.storeCanaryVersion({
            deploymentId,
            promptKey,
            content: newContent,
            metadata,
            trafficPercentage: this.CANARY_PERCENTAGE,
            deployedAt: new Date()
        });
        
        // Initialize metrics collection
        await this.metricsCollector.initializeCanaryMetrics(deploymentId);
        
        // Schedule evaluation
        await this.scheduleCanaryEvaluation(deploymentId);
        
        // Update routing rules
        await this.updatePromptRouting(promptKey, deploymentId);
        
        return {
            deploymentId,
            status: 'deployed',
            trafficPercentage: this.CANARY_PERCENTAGE,
            evaluationScheduledFor: new Date(Date.now() + this.EVALUATION_DURATION)
        };
    }
    
    async evaluateCanaryPerformance(deploymentId: string): Promise<EvaluationResult> {
        const metrics = await this.metricsCollector.getCanaryMetrics(deploymentId);
        const controlMetrics = await this.metricsCollector.getControlMetrics(deploymentId);
        
        const evaluation = {
            successRate: this.compareSuccessRate(metrics.successRate, controlMetrics.successRate),
            latency: this.compareLatency(metrics.avgLatency, controlMetrics.avgLatency),
            userSatisfaction: this.compareCSAT(metrics.csat, controlMetrics.csat),
            handoffRate: this.compareHandoffRate(metrics.handoffRate, controlMetrics.handoffRate)
        };
        
        const overallScore = this.calculateOverallScore(evaluation);
        
        if (overallScore >= 0.95) {
            // Canary performs as good as or better than control
            await this.promoteCanaryToProduction(deploymentId);
            return { decision: 'promote', score: overallScore, details: evaluation };
        } else if (overallScore < 0.85) {
            // Canary performs significantly worse
            await this.rollbackCanary(deploymentId);
            return { decision: 'rollback', score: overallScore, details: evaluation };
        } else {
            // Inconclusive, extend evaluation period
            await this.extendCanaryEvaluation(deploymentId);
            return { decision: 'extend', score: overallScore, details: evaluation };
        }
    }
    
    private compareSuccessRate(canary: number, control: number): number {
        // Success rate comparison with 95% confidence interval
        const difference = canary - control;
        const threshold = 0.02; // 2% threshold
        
        if (difference < -threshold) return 0.0; // Significantly worse
        if (difference > threshold) return 1.0;  // Significantly better
        return 0.8; // No significant difference
    }
    
    private async promoteCanaryToProduction(deploymentId: string): Promise<void> {
        const canaryVersion = await this.promptStore.getCanaryVersion(deploymentId);
        
        // Gradually increase traffic: 5% -> 25% -> 50% -> 100%
        for (const percentage of [25, 50, 100]) {
            await this.updateTrafficPercentage(deploymentId, percentage);
            await this.sleep(30 * 60 * 1000); // Wait 30 minutes between increases
            
            // Monitor for any issues
            const quickMetrics = await this.metricsCollector.getQuickMetrics(deploymentId, 30);
            if (quickMetrics.errorRate > 0.02) {
                await this.rollbackCanary(deploymentId);
                throw new Error(`Rollback triggered during promotion at ${percentage}% traffic`);
            }
        }
        
        // Mark as stable and clean up canary infrastructure
        await this.markAsProduction(deploymentId);
        await this.cleanupCanaryInfrastructure(deploymentId);
        
        // Notify team of successful deployment
        await this.notificationService.notifyPromptPromotion(canaryVersion);
    }
}
```

---

## Integration Specifications

### CRM Integration

```typescript
// integrations/crm-integration.ts
class CRMIntegration {
    private readonly BASE_URL = process.env.CRM_BASE_URL;
    private readonly API_KEY = process.env.CRM_API_KEY;
    private readonly RATE_LIMIT = 10; // 10 requests per second
    
    async syncLead(leadData: LeadData): Promise<CRMSyncResult> {
        try {
            // Apply rate limiting
            await this.rateLimiter.acquire();
            
            // Transform data to CRM format
            const crmPayload = await this.transformToCSMFormat(leadData);
            
            // Send to CRM with retry logic
            const response = await this.makeRetriableRequest({
                url: `${this.BASE_URL}/api/v1/leads`,
                method: 'POST',
                data: crmPayload,
                headers: {
                    'Authorization': `Bearer ${this.API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });
            
            // Handle response and update local records
            if (response.success) {
                await this.updateLocalLead(leadData.lead_id, {
                    crm_id: response.data.id,
                    sync_status: 'synced',
                    last_sync_at: new Date()
                });
                
                return { 
                    success: true, 
                    crm_id: response.data.id,
                    sync_timestamp: new Date()
                };
            }
            
        } catch (error) {
            await this.handleSyncError(leadData.lead_id, error);
            throw error;
        }
    }
    
    async setupWebhookHandling(): Promise<void> {
        // Webhook endpoint to receive CRM updates
        this.app.post('/webhooks/crm', async (req, res) => {
            try {
                // Verify webhook signature
                const isValid = await this.verifyWebhookSignature(
                    req.body, 
                    req.headers['x-crm-signature']
                );
                
                if (!isValid) {
                    return res.status(401).json({ error: 'Invalid signature' });
                }
                
                // Process webhook event
                await this.processWebhookEvent(req.body);
                
                res.status(200).json({ success: true });
                
            } catch (error) {
                console.error('Webhook processing failed:', error);
                res.status(500).json({ error: 'Processing failed' });
            }
        });
    }
    
    private async processWebhookEvent(event: CRMWebhookEvent): Promise<void> {
        switch (event.type) {
            case 'lead.updated':
                await this.handleLeadUpdate(event.data);
                break;
            case 'lead.status_changed':
                await this.handleLeadStatusChange(event.data);
                break;
            case 'opportunity.created':
                await this.handleOpportunityCreated(event.data);
                break;
            default:
                console.log(`Unhandled webhook event type: ${event.type}`);
        }
    }
}
```

### Payment Gateway Integration

```typescript
// integrations/payment-gateway.ts
class PaymentGatewayIntegration {
    private razorpay: Razorpay;
    private paymentService: PaymentService;
    
    constructor() {
        this.razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY_ID,
            key_secret: process.env.RAZORPAY_KEY_SECRET
        });
    }
    
    async createPaymentOrder(bookingId: string, amount: number): Promise<PaymentOrder> {
        const booking = await this.bookingService.getBooking(bookingId);
        
        const orderOptions = {
            amount: amount * 100, // Amount in paise
            currency: 'INR',
            receipt: `booking_${bookingId}`,
            notes: {
                booking_id: bookingId,
                user_id: booking.user_id,
                property_id: booking.property_id
            }
        };
        
        const order = await this.razorpay.orders.create(orderOptions);
        
        // Store order details
        await this.paymentService.createPaymentRecord({
            booking_id: bookingId,
            gateway_order_id: order.id,
            amount: amount,
            status: 'initiated',
            gateway: 'razorpay'
        });
        
        return {
            order_id: order.id,
            amount: amount,
            currency: 'INR',
            key: process.env.RAZORPAY_KEY_ID
        };
    }
    
    async handlePaymentWebhook(payload: any, signature: string): Promise<void> {
        try {
            // Verify signature
            const isValid = this.verifyWebhookSignature(payload, signature);
            if (!isValid) {
                throw new Error('Invalid webhook signature');
            }
            
            const event = payload.event;
            const paymentData = payload.payload.payment.entity;
            
            switch (event) {
                case 'payment.captured':
                    await this.handlePaymentSuccess(paymentData);
                    break;
                case 'payment.failed':
                    await this.handlePaymentFailure(paymentData);
                    break;
                default:
                    console.log(`Unhandled payment event: ${event}`);
            }
            
        } catch (error) {
            console.error('Payment webhook processing failed:', error);
            throw error;
        }
    }
    
    private async handlePaymentSuccess(paymentData: any): Promise<void> {
        const orderId = paymentData.order_id;
        const paymentId = paymentData.id;
        const amount = paymentData.amount / 100;
        
        // Update payment record
        await this.paymentService.updatePaymentStatus(orderId, {
            gateway_payment_id: paymentId,
            status: 'completed',
            completed_at: new Date(),
            gateway_response: paymentData
        });
        
        // Update booking status
        const booking = await this.bookingService.getBookingByOrderId(orderId);
        await this.bookingService.updateBookingStatus(booking.booking_id, 'payment_received');
        
        // Trigger downstream workflows
        await this.eventBus.publish({
            eventType: 'PAYMENT_COMPLETED',
            data: {
                booking_id: booking.booking_id,
                amount: amount,
                payment_id: paymentId
            }
        });
        
        // Send confirmation notifications
        await this.notificationService.sendPaymentConfirmation(
            booking.user_id,
            booking.booking_id,
            amount
        );
    }
    
    async implementRetryLogic(bookingId: string): Promise<void> {
        const maxRetries = 3;
        const retryDelays = [24, 48, 72]; // Hours
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            const delayHours = retryDelays[attempt - 1];
            
            // Schedule retry notification
            await this.scheduleRetryNotification(bookingId, attempt, delayHours);
            
            // Wait for the scheduled time
            await this.delay(delayHours * 60 * 60 * 1000);
            
            // Check if payment was completed manually
            const payment = await this.paymentService.getPaymentByBookingId(bookingId);
            if (payment.status === 'completed') {
                break; // Payment completed, stop retrying
            }
            
            // Send retry notification
            await this.sendRetryNotification(bookingId, attempt);
            
            if (attempt === maxRetries) {
                // Final attempt failed, escalate to support
                await this.escalateToSupport(bookingId);
            }
        }
    }
}
```

### VR Tour Integration

```typescript
// integrations/vr-tour.ts
class VRTourIntegration {
    private matterportAPI: MatterportAPI;
    
    async uploadAndProcessVRTour(
        propertyId: string, 
        tourData: VRTourData
    ): Promise<VRTourResult> {
        try {
            // Upload 360° images to Matterport
            const uploadResults = await Promise.all(
                tourData.images.map(image => 
                    this.matterportAPI.uploadImage(image)
                )
            );
            
            // Create virtual tour
            const tour = await this.matterportAPI.createTour({
                name: `${tourData.propertyName} - Virtual Tour`,
                description: tourData.description,
                images: uploadResults.map(r => r.imageId),
                floorPlan: tourData.floorPlan,
                tags: tourData.amenities
            });
            
            // Generate different viewing formats
            const tourFormats = {
                embed_url: tour.embed_url,
                standalone_url: tour.standalone_url,
                mobile_deep_link: `onemantra://vr-tour/${tour.id}`,
                webgl_url: tour.webgl_url
            };
            
            // Store tour information
            await this.propertyService.updateVRTours(propertyId, {
                tour_id: tour.id,
                formats: tourFormats,
                created_at: new Date(),
                status: 'active'
            });
            
            // Generate thumbnail and preview images
            const thumbnails = await this.generateThumbnails(tour.id);
            
            return {
                tour_id: tour.id,
                formats: tourFormats,
                thumbnails: thumbnails,
                processing_status: 'completed'
            };
            
        } catch (error) {
            console.error('VR tour processing failed:', error);
            throw error;
        }
    }
    
    async embedVRTourInApp(tourId: string): Promise<VREmbedConfig> {
        const tour = await this.matterportAPI.getTour(tourId);
        
        return {
            iframe_src: tour.embed_url,
            dimensions: {
                width: '100%',
                height: '400px'
            },
            options: {
                autoplay: false,
                controls: true,
                fullscreen: true,
                vr_mode: true
            },
            mobile_config: {
                deep_link: `onemantra://vr-tour/${tourId}`,
                fallback_url: tour.mobile_url
            }
        };
    }
}
```

### IoT Integration

```typescript
// integrations/iot-integration.ts
class IoTIntegration {
    private mqttClient: MQTTClient;
    private deviceRegistry: DeviceRegistry;
    
    async setupMQTTConnection(): Promise<void> {
        this.mqttClient = mqtt.connect(process.env.IOT_BROKER_URL, {
            clientId: 'one-mantra-backend',
            username: process.env.IOT_USERNAME,
            password: process.env.IOT_PASSWORD,
            clean: true,
            reconnectPeriod: 5000
        });
        
        this.mqttClient.on('connect', () => {
            console.log('Connected to IoT broker');
            this.subscribeToTopics();
        });
        
        this.mqttClient.on('message', async (topic, message) => {
            try {
                await this.processIoTMessage(topic, message.toString());
            } catch (error) {
                console.error('IoT message processing failed:', error);
            }
        });
    }
    
    private subscribeToTopics(): void {
        const topics = [
            'devices/+/telemetry',      // Device telemetry data
            'devices/+/alerts',         // Device alerts
            'security/+/events',        // Security events
            'energy/+/readings'         // Smart meter readings
        ];
        
        topics.forEach(topic => {
            this.mqttClient.subscribe(topic, { qos: 1 });
        });
    }
    
    async processIoTMessage(topic: string, message: string): Promise<void> {
        const [category, deviceId, messageType] = topic.split('/');
        const payload = JSON.parse(message);
        
        // Store raw IoT event
        await this.storeIoTEvent({
            device_id: deviceId,
            topic: topic,
            payload: payload,
            timestamp: new Date()
        });
        
        // Process based on message type
        switch (messageType) {
            case 'telemetry':
                await this.processTelemetryData(deviceId, payload);
                break;
            case 'alerts':
                await this.processDeviceAlert(deviceId, payload);
                break;
            case 'events':
                await this.processSecurityEvent(deviceId, payload);
                break;
            case 'readings':
                await this.processEnergyReading(deviceId, payload);
                break;
        }
    }
    
    private async processSecurityEvent(deviceId: string, payload: any): Promise<void> {
        const device = await this.deviceRegistry.getDevice(deviceId);
        
        if (payload.event_type === 'motion_detected') {
            // Check if it's during restricted hours
            const currentHour = new Date().getHours();
            if (currentHour >= 22 || currentHour <= 6) {
                await this.triggerSecurityAlert(device.property_id, {
                    type: 'unauthorized_motion',
                    location: device.location,
                    timestamp: new Date(),
                    device_id: deviceId
                });
            }
        }
        
        if (payload.event_type === 'door_forced') {
            await this.triggerSecurityAlert(device.property_id, {
                type: 'forced_entry_attempt',
                location: device.location,
                timestamp: new Date(),
                device_id: deviceId,
                severity: 'high'
            });
        }
    }
    
    private async processEnergyReading(deviceId: string, payload: any): Promise<void> {
        const device = await this.deviceRegistry.getDevice(deviceId);
        
        // Store energy reading
        await this.energyService.recordReading({
            device_id: deviceId,
            unit_id: device.unit_id,
            reading_type: payload.type, // electricity, water, gas
            value: payload.value,
            unit: payload.unit,
            timestamp: new Date(payload.timestamp)
        });
        
        // Check for anomalies
        const isAnomaly = await this.detectEnergyAnomaly(deviceId, payload);
        if (isAnomaly) {
            await this.notifyResidentOfAnomalousUsage(device.unit_id, payload);
        }
        
        // Update real-time dashboard
        await this.updateEnergyDashboard(device.unit_id, payload);
    }
}
```

### Blockchain Integration

```typescript
// integrations/blockchain-integration.ts
class BlockchainIntegration {
    private fabric: FabricNetwork;
    private contract: Contract;
    
    async initializeHyperledgerConnection(): Promise<void> {
        // Load network configuration
        const ccpPath = path.resolve(__dirname, '..', 'network', 'connection-org1.json');
        const ccp = JSON.parse(fs.readFileSync(ccpPath, 'utf8'));
        
        // Create CA client
        const caInfo = ccp.certificateAuthorities['ca.org1.example.com'];
        const caTLSCACerts = caInfo.tlsCACerts.pem;
        const ca = new FabricCAServices(caInfo.url, { 
            trustedRoots: caTLSCACerts, 
            verify: false 
        }, caInfo.caName);
        
        // Create file system wallet
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = await Wallets.newFileSystemWallet(walletPath);
        
        // Connect to gateway
        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: 'appUser',
            discovery: { enabled: true, asLocalhost: true }
        });
        
        // Get network and contract
        const network = await gateway.getNetwork('mychannel');
        this.contract = network.getContract('property-records');
    }
    
    async recordAgreement(agreementData: AgreementData): Promise<string> {
        try {
            // Create document hash
            const documentHash = crypto
                .createHash('sha256')
                .update(JSON.stringify(agreementData.content))
                .digest('hex');
            
            // Prepare blockchain record
            const blockchainRecord = {
                agreement_id: agreementData.agreement_id,
                document_hash: documentHash,
                parties_involved: agreementData.parties.map(p => p.public_key),
                agreement_type: agreementData.type,
                effective_date: agreementData.effective_date.toISOString(),
                created_by: agreementData.created_by,
                timestamp: new Date().toISOString()
            };
            
            // Submit transaction to blockchain
            const result = await this.contract.submitTransaction(
                'RecordAgreement',
                JSON.stringify(blockchainRecord)
            );
            
            const transactionId = result.toString();
            
            // Store reference in local database
            await this.blockchainService.createRecord({
                agreement_id: agreementData.agreement_id,
                document_hash: documentHash,
                parties_involved: agreementData.parties,
                agreement_type: agreementData.type,
                effective_date: agreementData.effective_date,
                blockchain_tx_hash: transactionId,
                ledger_status: 'confirmed'
            });
            
            return transactionId;
            
        } catch (error) {
            console.error('Blockchain recording failed:', error);
            throw error;
        }
    }
    
    async verifyAgreement(agreementId: string, documentContent: any): Promise<VerificationResult> {
        try {
            // Get blockchain record
            const blockchainRecord = await this.contract.evaluateTransaction(
                'GetAgreement',
                agreementId
            );
            
            const record = JSON.parse(blockchainRecord.toString());
            
            // Calculate hash of provided content
            const providedHash = crypto
                .createHash('sha256')
                .update(JSON.stringify(documentContent))
                .digest('hex');
            
            // Compare hashes
            const isValid = record.document_hash === providedHash;
            
            return {
                is_valid: isValid,
                blockchain_hash: record.document_hash,
                provided_hash: providedHash,
                recorded_at: record.timestamp,
                parties: record.parties_involved,
                tx_hash: record.tx_id
            };
            
        } catch (error) {
            console.error('Agreement verification failed:', error);
            throw error;
        }
    }
    
    async getAgreementHistory(agreementId: string): Promise<AgreementHistory[]> {
        try {
            const historyResult = await this.contract.evaluateTransaction(
                'GetAgreementHistory',
                agreementId
            );
            
            const history = JSON.parse(historyResult.toString());
            
            return history.map(entry => ({
                transaction_id: entry.txId,
                timestamp: new Date(entry.timestamp),
                action: entry.value.action || 'created',
                modified_by: entry.value.created_by,
                changes: entry.value.changes || null
            }));
            
        } catch (error) {
            console.error('Failed to get agreement history:', error);
            throw error;
        }
    }
}
```

---

## Development Roadmap

### Phase 1: Foundation & Core Services (Months 1-6)

**Month 1-2: Infrastructure & Backend Setup**
```yaml
Sprint 1-2:
  - AWS infrastructure setup (EKS, RDS, ElastiCache, S3)
  - CI/CD pipeline configuration
  - Basic microservices architecture (User Mgmt, API Gateway)
  - PostgreSQL schema implementation
  - Authentication service with OAuth 2.0/JWT

Sprint 3-4:
  - Property catalog service
  - Basic lead management service
  - Document management with S3 integration
  - Event bus setup (SNS/SQS)
  - Basic API endpoints and testing
```

**Month 3-4: AI Gateway & Frontend Foundation**
```yaml
Sprint 5-6:
  - Claude Sonnet 4.5 integration (Amazon Bedrock)
  - AI Gateway service with prompt management
  - React Native app foundation with navigation
  - Basic property listing screens
  - Lead capture forms and validation

Sprint 7-8:
  - AI chatbot integration in mobile app
  - Lead qualification workflows
  - React web admin portal foundation
  - Basic dashboard with property management
  - User management interface
```

**Month 5-6: Booking & Payment Integration**
```yaml
Sprint 9-10:
  - Booking service implementation
  - Payment gateway integration (Razorpay, PayU)
  - EOI submission workflow
  - Document upload and OCR processing
  - Basic reporting and analytics

Sprint 11-12:
  - VR tour integration (Matterport)
  - Site visit scheduling system
  - Notification service (email, SMS, push)
  - Mobile app UI/UX refinement
  - Admin portal enhancements
```

### Phase 2: Channel Partner & Advanced AI (Months 7-12)

**Month 7-8: Channel Partner Portal**
```yaml
Sprint 13-14:
  - Channel partner registration and onboarding
  - Commission calculation engine
  - Lead assignment algorithms
  - Partner dashboard with performance metrics
  - Referral system foundation

Sprint 15-16:
  - Partner mobile app development
  - Commission tracking and payout workflows
  - Team management features
  - Marketing collateral library
  - Training module integration
```

**Month 9-10: Advanced AI Workflows**
```yaml
Sprint 17-18:
  - Advanced lead qualification agents
  - Objection handling AI workflows
  - Site visit coordination automation
  - AI-powered commission management
  - Sentiment analysis implementation

Sprint 19-20:
  - Behavioral analytics integration
  - Predictive lead scoring
  - Automated follow-up sequences
  - AI prompt versioning and canary deployments
  - Performance optimization
```

**Month 11-12: NRI & Referral Programs**
```yaml
Sprint 21-22:
  - NRI helpdesk integration
  - Gamification engine for referrals
  - Points, badges, and leaderboards
  - Multi-language support (Hindi, Marathi)
  - Localization framework

Sprint 23-24:
  - Referral tracking and analytics
  - Reward distribution system
  - Social sharing integration
  - NRI-specific workflows and support
  - Advanced reporting dashboard
```

### Phase 3: Society Management (Months 13-18)

**Month 13-14: Core Society Features**
```yaml
Sprint 25-26:
  - Maintenance request system
  - Visitor management with QR codes
  - Basic amenity booking
  - Resident communication platform
  - Security alert system

Sprint 27-28:
  - Grievance management workflow
  - Financial management and billing
  - Committee member interfaces
  - Vendor management backend
  - Notice board and announcements
```

**Month 15-16: Advanced Society Operations**
```yaml
Sprint 29-30:
  - Advanced visitor categorization
  - Amenity booking with dynamic pricing
  - SOS and emergency protocols
  - AI-powered grievance triage
  - Automated resolution workflows

Sprint 31-32:
  - Community engagement features
  - Event management system
  - Polling and voting mechanisms
  - Neighbor connect features
  - Advanced analytics dashboard
```

**Month 17-18: IoT Integration & Blockchain**
```yaml
Sprint 33-34:
  - IoT device integration (smart meters, CCTV)
  - MQTT broker setup and management
  - Real-time monitoring dashboards
  - Energy consumption analytics
  - Security event processing

Sprint 35-36:
  - Blockchain integration (Hyperledger Fabric)
  - Agreement recording and verification
  - Audit trail implementation
  - Document integrity verification
  - Compliance reporting automation
```

### Phase 4: Scale & Optimization (Months 19-24)

**Month 19-20: Performance & Scaling**
```yaml
Sprint 37-38:
  - Performance optimization across services
  - Database query optimization
  - Caching strategy implementation
  - CDN optimization for media
  - Load testing and capacity planning

Sprint 39-40:
  - Auto-scaling configuration
  - Multi-region deployment preparation
  - Disaster recovery implementation
  - Backup and restore procedures
  - Security hardening
```

**Month 21-22: Advanced Analytics & AI**
```yaml
Sprint 41-42:
  - Advanced analytics and reporting
  - Machine learning model training
  - Predictive analytics implementation
  - Custom report builder
  - Business intelligence dashboard

Sprint 43-44:
  - AI model optimization
  - A/B testing framework
  - Personalization engine
  - Recommendation systems
  - Advanced user segmentation
```

**Month 23-24: Enterprise Features & Launch**
```yaml
Sprint 45-46:
  - Multi-property management
  - White-labeling capabilities
  - Enterprise security features
  - Advanced compliance tools
  - Integration marketplace

Sprint 47-48:
  - Final testing and optimization
  - Production deployment
  - Go-live support
  - User training and documentation
  - Post-launch monitoring and support
```

### Ongoing: DevOps & Maintenance

**Continuous Activities:**
- Security updates and patches
- Performance monitoring and optimization
- User feedback integration
- Feature enhancements
- Third-party integration updates
- Compliance updates (RERA, data protection)
- AI model retraining and improvement
- Cost optimization initiatives

**Monthly Reviews:**
- Performance metrics analysis
- Cost optimization review
- Security audit
- User satisfaction surveys
- Feature usage analytics
- Technical debt assessment
- Vendor relationship management
- Capacity planning review

This comprehensive technical documentation provides the foundation for building ONE Mantra as a world-class, AI-first real estate platform that serves the complete lifecycle from enquiry to community living, with enterprise-grade scalability, security, and operational efficiency.