# ONE Mantra - AIOps Runbooks & Monitoring Configuration

## 1. Service Level Objectives (SLOs)

### Core SLOs Definition

```yaml
# SLO Configuration
service_level_objectives:
  availability:
    target: 99.9%
    measurement_window: 30d
    error_budget: 0.1%
    
  latency:
    target: 95% of requests < 300ms
    measurement_window: 30d
    percentile: 95
    
  ai_accuracy:
    target: 90% accuracy for lead qualification
    measurement_window: 7d
    
  user_satisfaction:
    target: CSAT > 4.0/5.0
    measurement_window: 30d

error_budget_policies:
  - name: "Fast Burn"
    conditions:
      - burn_rate: "> 14.4x"  # 2% of monthly budget in 1 hour
      - duration: "2m"
    alerts:
      - page_oncall: true
      - create_incident: true
      
  - name: "Slow Burn" 
    conditions:
      - burn_rate: "> 6x"     # 5% of monthly budget in 6 hours
      - duration: "15m"
    alerts:
      - slack_notification: true
      - email_team: true
```

### Monitoring Queries

```yaml
# Prometheus Queries for SLO Monitoring
queries:
  availability:
    good_events: 'sum(rate(http_requests_total{status!~"5.."}[5m]))'
    total_events: 'sum(rate(http_requests_total[5m]))'
    
  latency:
    good_events: 'sum(rate(http_request_duration_seconds_bucket{le="0.3"}[5m]))'
    total_events: 'sum(rate(http_request_duration_seconds_count[5m]))'
    
  ai_accuracy:
    good_events: 'sum(rate(ai_predictions_correct_total[5m]))'
    total_events: 'sum(rate(ai_predictions_total[5m]))'
    
  lead_conversion:
    good_events: 'sum(rate(leads_converted_total[5m]))'
    total_events: 'sum(rate(leads_qualified_total[5m]))'
```

## 2. Alert Configuration

### Critical Alerts

```yaml
# Alert Rules Configuration
groups:
  - name: "critical_alerts"
    rules:
      - alert: "HighErrorBudgetBurn"
        expr: |
          (
            rate(http_requests_total{status=~"5.."}[1h]) 
            / rate(http_requests_total[1h])
          ) > 0.02
        for: "2m"
        labels:
          severity: "critical"
          service: "one-mantra"
        annotations:
          summary: "High error budget burn rate detected"
          description: |
            Error rate is {{ $value | humanizePercentage }} which will 
            exhaust monthly error budget in less than 2 days
          runbook_url: "https://runbooks.onemantra.com/high-error-budget-burn"
        
      - alert: "AIAgentHighLatency"
        expr: |
          histogram_quantile(0.95, 
            rate(ai_response_duration_seconds_bucket[5m])
          ) > 0.5
        for: "10m"
        labels:
          severity: "warning"
          service: "ai-gateway"
        annotations:
          summary: "AI agent response latency is high"
          description: "95th percentile latency is {{ $value }}s"
          runbook_url: "https://runbooks.onemantra.com/ai-latency-high"
        
      - alert: "DatabaseConnectionPoolExhausted"
        expr: 'db_connections_active / db_connections_max > 0.9'
        for: "5m"
        labels:
          severity: "critical"
          service: "database"
        annotations:
          summary: "Database connection pool near exhaustion"
          description: |
            Connection pool usage is at {{ $value | humanizePercentage }}
          runbook_url: "https://runbooks.onemantra.com/db-connections"
          
      - alert: "PaymentGatewayFailureRate"
        expr: |
          (
            rate(payment_transactions_total{status="failed"}[5m]) 
            / rate(payment_transactions_total[5m])
          ) > 0.05
        for: "5m"
        labels:
          severity: "critical"
          service: "payment-gateway"
        annotations:
          summary: "High payment failure rate detected"
          description: "Payment failure rate is {{ $value | humanizePercentage }}"
          runbook_url: "https://runbooks.onemantra.com/payment-failures"
```

### Warning Alerts

```yaml
  - name: "warning_alerts"
    rules:
      - alert: "LeadQualificationAccuracyDrop"
        expr: 'ai_lead_qualification_accuracy_ratio < 0.85'
        for: "15m"
        labels:
          severity: "warning"
          service: "ai-gateway"
        annotations:
          summary: "AI lead qualification accuracy dropped"
          description: "Accuracy dropped to {{ $value | humanizePercentage }}"
          runbook_url: "https://runbooks.onemantra.com/ai-accuracy-drop"
          
      - alert: "HighMemoryUsage"
        expr: 'memory_usage_percent > 85'
        for: "15m"
        labels:
          severity: "warning"
          service: "infrastructure"
        annotations:
          summary: "High memory usage on {{ $labels.instance }}"
          description: "Memory usage is {{ $value }}%"
          runbook_url: "https://runbooks.onemantra.com/high-memory-usage"
          
      - alert: "DiskSpaceRunningLow"
        expr: 'disk_usage_percent > 80'
        for: "30m"
        labels:
          severity: "warning"
          service: "infrastructure"
        annotations:
          summary: "Disk space running low on {{ $labels.instance }}"
          description: "Disk usage is {{ $value }}%"
          runbook_url: "https://runbooks.onemantra.com/disk-space-low"
```

## 3. Incident Response Runbooks

### Runbook: High Error Budget Burn

```markdown
# Runbook: High Error Budget Burn Rate

## Overview
This alert fires when our error rate is consuming error budget at a rate that would exhaust our monthly allowance in less than 2 days.

## Severity: CRITICAL
**Response Time: 15 minutes**

## Immediate Actions

### Step 1: Assess Impact (2 minutes)
1. Check the ONE Mantra status dashboard
2. Verify if users are reporting issues
3. Check if this correlates with a recent deployment

### Step 2: Identify Root Cause (8 minutes)
1. **Check Recent Deployments**
   ```bash
   kubectl get deployments -n one-mantra -o wide
   kubectl rollout history deployment/api-gateway -n one-mantra
   ```

2. **Check Service Health**
   ```bash
   # Check pod status
   kubectl get pods -n one-mantra | grep -v Running
   
   # Check service logs
   kubectl logs -n one-mantra deployment/api-gateway --tail=100
   ```

3. **Check Database Performance**
   - Login to RDS Performance Insights
   - Check for slow queries or connection issues
   - Verify connection pool status

4. **Check External Dependencies**
   - Payment gateway status
   - CRM API availability
   - Claude Sonnet 4.5 API limits

### Step 3: Immediate Mitigation (5 minutes)
Based on root cause:

**If Recent Deployment:**
```bash
# Rollback to previous version
kubectl rollout undo deployment/api-gateway -n one-mantra
kubectl rollout status deployment/api-gateway -n one-mantra
```

**If Database Issues:**
```bash
# Scale read replicas
aws rds modify-db-instance --db-instance-identifier one-mantra-read-replica --allocated-storage 200
```

**If External Dependency:**
- Enable circuit breaker patterns
- Switch to fallback responses for AI queries

## Investigation Playbook

### Database Investigation
```sql
-- Check for blocking queries
SELECT 
    blocked_pid,
    blocking_pid,
    blocked_statement,
    blocking_statement
FROM pg_blocking_pids();

-- Check connection count
SELECT 
    state,
    COUNT(*) 
FROM pg_stat_activity 
GROUP BY state;

-- Check slow queries
SELECT 
    query,
    state,
    query_start,
    now() - query_start AS duration
FROM pg_stat_activity
WHERE now() - query_start > interval '30 seconds'
    AND state != 'idle'
ORDER BY duration DESC;
```

### Application Investigation
```bash
# Check error logs
kubectl logs -n one-mantra deployment/api-gateway | grep ERROR | tail -50

# Check resource utilization
kubectl top pods -n one-mantra

# Check service endpoints
kubectl get endpoints -n one-mantra
```

## Escalation
- **If not resolved in 15 minutes:** Page Engineering Manager
- **If customer impact continues:** Page VP Engineering
- **If affects payments:** Page Business Operations

## Post-Incident Actions
1. Create post-mortem document
2. Update monitoring if blind spots identified
3. Implement additional safeguards
4. Review deployment process if deployment-related

## Prevention
- Implement canary deployments for all services
- Add more comprehensive testing
- Improve monitoring coverage
- Regular chaos engineering exercises
```

### Runbook: AI Model Performance Degradation

```markdown
# Runbook: AI Model Performance Degradation

## Overview
AI agents showing decreased accuracy or increased latency affecting user experience.

## Severity: WARNING → CRITICAL (if accuracy < 75%)
**Response Time: 30 minutes**

## Immediate Actions

### Step 1: Assess AI Performance (5 minutes)
1. Check AI Operations Dashboard
2. Review recent prompt changes
3. Verify Claude Sonnet 4.5 API status

### Step 2: Identify Root Cause (15 minutes)

**Check Canary Deployments**
```bash
# Check canary prompt deployments
curl -H "Authorization: Bearer $API_TOKEN" \
  https://api.onemantra.com/api/v1/ai/prompts?status=canary

# Check canary metrics
curl -H "Authorization: Bearer $API_TOKEN" \
  https://api.onemantra.com/api/v1/ai/prompts/canary-metrics
```

**Check API Limits and Errors**
```bash
# Check Claude API rate limits
grep "rate_limit" /var/log/ai-gateway/claude-api.log | tail -20

# Check API error rates
grep "api_error" /var/log/ai-gateway/claude-api.log | tail -20
```

**Check Training Data Drift**
- Review recent data changes
- Check if new conversation patterns emerged
- Verify if edge cases increased

### Step 3: Immediate Mitigation (10 minutes)

**If Canary Deployment Issue:**
```bash
# Rollback canary prompt
curl -X POST -H "Authorization: Bearer $API_TOKEN" \
  https://api.onemantra.com/api/v1/ai/prompts/rollback \
  -d '{"deployment_id": "canary_12345"}'
```

**If API Rate Limiting:**
- Implement exponential backoff
- Scale to multiple API keys
- Enable caching for repeated queries

**If Model Degradation:**
```python
# Increase human handoff threshold temporarily
import requests

response = requests.put(
    'https://api.onemantra.com/api/v1/ai/config',
    headers={'Authorization': f'Bearer {API_TOKEN}'},
    json={
        'confidence_threshold': 0.9,  # Increased from 0.8
        'handoff_enabled': True
    }
)
```

## Investigation Queries

```python
# Query recent AI interactions
from datetime import datetime, timedelta
import pandas as pd

# Get last 24 hours of AI interactions
query = """
SELECT 
    session_id,
    prompt_version,
    user_input,
    ai_response,
    confidence_score,
    user_satisfaction,
    handoff_required,
    created_at
FROM ai_interactions 
WHERE created_at > NOW() - INTERVAL '24 hours'
    AND confidence_score < 0.8
ORDER BY created_at DESC
LIMIT 1000
"""

df = pd.read_sql(query, connection)

# Analyze patterns
low_confidence = df[df['confidence_score'] < 0.7]
print(f"Low confidence interactions: {len(low_confidence)}")
print(f"Average confidence: {df['confidence_score'].mean():.3f}")
print(f"Handoff rate: {df['handoff_required'].mean():.3f}")
```

## Escalation
- **If accuracy < 80%:** Notify AI/ML Team Lead
- **If affects lead conversion:** Notify Sales Operations
- **If affects critical user journeys:** Page Product Manager

## Communication Template
```
🤖 AI PERFORMANCE ALERT

Status: [INVESTIGATING/MITIGATED/RESOLVED]
Impact: AI accuracy dropped to X% (target: 90%)
Root Cause: [TBD/Identified/Fixed]
Actions Taken:
- ✅ Rolled back canary prompt deployment
- ✅ Increased human handoff threshold
- 🔄 Investigating training data drift

Next Update: In 30 minutes
```
```

### Runbook: Database Performance Issues

```markdown
# Runbook: Database Performance Issues

## Overview
Database showing high CPU, slow queries, or connection pool exhaustion.

## Severity: WARNING → CRITICAL
**Response Time: 20 minutes**

## Immediate Actions

### Step 1: Assess Database Health (3 minutes)
```bash
# Check RDS metrics
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name CPUUtilization \
  --dimensions Name=DBInstanceIdentifier,Value=one-mantra-db \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average

# Check connection count
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name DatabaseConnections \
  --dimensions Name=DBInstanceIdentifier,Value=one-mantra-db \
  --start-time $(date -u -d '30 minutes ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average
```

### Step 2: Identify Problematic Queries (10 minutes)
```sql
-- Connect to database
psql -h one-mantra-db.cluster-xyz.ap-south-1.rds.amazonaws.com -U admin onemantra

-- Check current running queries
SELECT 
    pid,
    now() - pg_stat_activity.query_start AS duration,
    query,
    state
FROM pg_stat_activity
WHERE (now() - pg_stat_activity.query_start) > interval '5 minutes'
    AND state = 'active'
ORDER BY duration DESC;

-- Check blocking queries
SELECT
    blocked_locks.pid AS blocked_pid,
    blocked_activity.usename AS blocked_user,
    blocking_locks.pid AS blocking_pid,
    blocking_activity.usename AS blocking_user,
    blocked_activity.query AS blocked_statement,
    blocking_activity.query AS blocking_statement
FROM pg_catalog.pg_locks blocked_locks
JOIN pg_catalog.pg_stat_activity blocked_activity 
    ON blocked_activity.pid = blocked_locks.pid
JOIN pg_catalog.pg_locks blocking_locks 
    ON blocking_locks.locktype = blocked_locks.locktype
    AND blocking_locks.database IS NOT DISTINCT FROM blocked_locks.database
    AND blocking_locks.relation IS NOT DISTINCT FROM blocked_locks.relation
    AND blocking_locks.page IS NOT DISTINCT FROM blocked_locks.page
    AND blocking_locks.tuple IS NOT DISTINCT FROM blocked_locks.tuple
    AND blocking_locks.virtualxid IS NOT DISTINCT FROM blocked_locks.virtualxid
    AND blocking_locks.transactionid IS NOT DISTINCT FROM blocked_locks.transactionid
    AND blocking_locks.classid IS NOT DISTINCT FROM blocked_locks.classid
    AND blocking_locks.objid IS NOT DISTINCT FROM blocked_locks.objid
    AND blocking_locks.objsubid IS NOT DISTINCT FROM blocked_locks.objsubid
    AND blocking_locks.pid != blocked_locks.pid
JOIN pg_catalog.pg_stat_activity blocking_activity 
    ON blocking_activity.pid = blocking_locks.pid
WHERE NOT blocked_locks.granted;

-- Check slow queries from pg_stat_statements
SELECT 
    query,
    calls,
    total_time,
    mean_time,
    rows
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 20;
```

### Step 3: Immediate Mitigation (7 minutes)

**If CPU > 90%:**
```sql
-- Kill long-running queries (be careful!)
SELECT pg_terminate_backend(pid) 
FROM pg_stat_activity 
WHERE now() - pg_stat_activity.query_start > interval '10 minutes'
    AND state = 'active'
    AND query NOT LIKE '%pg_stat_activity%';
```

**If Connection Pool Exhausted:**
```bash
# Scale application pods to reduce connection pressure
kubectl scale deployment api-gateway --replicas=2 -n one-mantra

# Or increase RDS connection limit temporarily
aws rds modify-db-instance \
    --db-instance-identifier one-mantra-db \
    --max-allocated-storage 1000 \
    --apply-immediately
```

**If Blocking Locks:**
```sql
-- Terminate blocking sessions (nuclear option)
SELECT pg_terminate_backend(blocking_pid)
FROM (
    -- [previous blocking query here]
) AS blocking_queries;
```

## Performance Analysis

```sql
-- Analyze table sizes and row counts
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
    pg_stat_user_tables.n_tup_ins + pg_stat_user_tables.n_tup_upd + pg_stat_user_tables.n_tup_del as total_writes
FROM pg_tables
LEFT JOIN pg_stat_user_tables ON pg_tables.tablename = pg_stat_user_tables.relname
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Check index usage
SELECT 
    indexrelname,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes
ORDER BY idx_scan DESC;

-- Check for missing indexes
SELECT 
    schemaname,
    tablename,
    seq_scan,
    seq_tup_read,
    seq_scan / NULLIF(seq_tup_read, 0) AS avg_read_per_scan
FROM pg_stat_user_tables
WHERE seq_scan > 1000
ORDER BY seq_tup_read DESC;
```

## Recovery Actions
1. **Scale RDS instance** if consistently high CPU
2. **Add read replicas** for read-heavy workloads  
3. **Optimize slow queries** identified
4. **Add missing indexes** 
5. **Implement connection pooling** (PgBouncer)

## Escalation
- **If CPU > 95% for 10+ minutes:** Page Database Administrator
- **If affects user transactions:** Page Engineering Manager
- **If data corruption suspected:** Page VP Engineering immediately
```

## 4. Canary Deployment Process

### Canary Configuration

```yaml
# canary-config.yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: ai-gateway
  namespace: one-mantra
spec:
  replicas: 10
  strategy:
    canary:
      canaryService: ai-gateway-canary
      stableService: ai-gateway-stable
      trafficRouting:
        nginx:
          stableIngress: ai-gateway-ingress
      steps:
      - setWeight: 5   # 5% traffic to canary
      - pause:
          duration: 30m # Monitor for 30 minutes
      - analysis:
          templates:
          - templateName: success-rate
            args:
            - name: service-name
              value: ai-gateway-canary
      - setWeight: 25  # Increase to 25%
      - pause:
          duration: 30m
      - analysis:
          templates:
          - templateName: success-rate
          - templateName: response-time
      - setWeight: 50  # Increase to 50%
      - pause:
          duration: 1h # Longer monitoring
      - analysis:
          templates:
          - templateName: success-rate
          - templateName: response-time
          - templateName: user-satisfaction
      - setWeight: 100 # Full rollout
  selector:
    matchLabels:
      app: ai-gateway
  template:
    metadata:
      labels:
        app: ai-gateway
    spec:
      containers:
      - name: ai-gateway
        image: onemantra/ai-gateway:latest
        ports:
        - containerPort: 3000
---
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: success-rate
  namespace: one-mantra
spec:
  args:
  - name: service-name
  metrics:
  - name: success-rate
    interval: 5m
    count: 6
    successCondition: result[0] >= 0.95
    failureLimit: 2
    provider:
      prometheus:
        address: http://prometheus:9090
        query: |
          sum(rate(http_requests_total{job="{{args.service-name}}",status!~"5.."}[5m]))
          /
          sum(rate(http_requests_total{job="{{args.service-name}}"}[5m]))
```

### Automated Canary Analysis

```python
# canary-analyzer.py
import requests
import time
import logging
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class CanaryMetrics:
    success_rate: float
    latency_p95: float
    user_satisfaction: float
    handoff_rate: float
    error_rate: float

class CanaryAnalyzer:
    def __init__(self, prometheus_url: str, deployment_id: str):
        self.prometheus_url = prometheus_url
        self.deployment_id = deployment_id
        self.logger = logging.getLogger(__name__)
        
    def get_metrics(self, service_name: str) -> CanaryMetrics:
        """Get current metrics for a service."""
        queries = {
            'success_rate': f'rate(http_requests_total{{job="{service_name}",status!~"5.."}}[5m]) / rate(http_requests_total{{job="{service_name}"}}[5m])',
            'latency_p95': f'histogram_quantile(0.95, rate(http_request_duration_seconds_bucket{{job="{service_name}"}}[5m]))',
            'user_satisfaction': f'avg(user_satisfaction_score{{service="{service_name}"}})',
            'handoff_rate': f'rate(ai_handoffs_total{{service="{service_name}"}}[5m]) / rate(ai_interactions_total{{service="{service_name}"}}[5m])',
            'error_rate': f'rate(http_requests_total{{job="{service_name}",status=~"5.."}}[5m]) / rate(http_requests_total{{job="{service_name}"}}[5m])'
        }
        
        metrics = {}
        for metric_name, query in queries.items():
            response = requests.get(
                f"{self.prometheus_url}/api/v1/query",
                params={'query': query}
            )
            result = response.json()
            
            if result['status'] == 'success' and result['data']['result']:
                metrics[metric_name] = float(result['data']['result'][0]['value'][1])
            else:
                metrics[metric_name] = 0.0
                
        return CanaryMetrics(**metrics)
    
    def analyze_canary_performance(self, canary_service: str, stable_service: str) -> Dict:
        """Compare canary vs stable service performance."""
        canary_metrics = self.get_metrics(canary_service)
        stable_metrics = self.get_metrics(stable_service)
        
        # Calculate performance deltas
        deltas = {
            'success_rate_delta': canary_metrics.success_rate - stable_metrics.success_rate,
            'latency_delta': canary_metrics.latency_p95 - stable_metrics.latency_p95,
            'satisfaction_delta': canary_metrics.user_satisfaction - stable_metrics.user_satisfaction,
            'handoff_rate_delta': canary_metrics.handoff_rate - stable_metrics.handoff_rate,
            'error_rate_delta': canary_metrics.error_rate - stable_metrics.error_rate
        }
        
        # Decision logic
        decision = self.make_rollout_decision(deltas)
        
        return {
            'canary_metrics': canary_metrics,
            'stable_metrics': stable_metrics,
            'deltas': deltas,
            'decision': decision,
            'timestamp': time.time()
        }
    
    def make_rollout_decision(self, deltas: Dict[str, float]) -> str:
        """Decide whether to promote, rollback, or continue canary."""
        
        # Critical failure conditions (immediate rollback)
        if deltas['success_rate_delta'] < -0.02:  # 2% drop in success rate
            return 'ROLLBACK'
        if deltas['error_rate_delta'] > 0.01:     # 1% increase in error rate
            return 'ROLLBACK'
        if deltas['latency_delta'] > 0.5:         # 500ms increase in latency
            return 'ROLLBACK'
            
        # Good performance conditions (promote)
        good_conditions = [
            deltas['success_rate_delta'] >= -0.005,  # < 0.5% drop in success rate
            deltas['latency_delta'] <= 0.1,          # < 100ms increase in latency
            deltas['satisfaction_delta'] >= -0.1,    # < 0.1 drop in satisfaction
            deltas['handoff_rate_delta'] <= 0.02     # < 2% increase in handoffs
        ]
        
        if all(good_conditions):
            return 'PROMOTE'
        
        # Default: continue monitoring
        return 'CONTINUE'
    
    def execute_decision(self, decision: str, canary_service: str):
        """Execute the rollout decision."""
        if decision == 'ROLLBACK':
            self.logger.critical(f"Rolling back canary deployment {self.deployment_id}")
            self.rollback_canary(canary_service)
        elif decision == 'PROMOTE':
            self.logger.info(f"Promoting canary deployment {self.deployment_id}")
            self.promote_canary(canary_service)
        else:
            self.logger.info(f"Continuing canary monitoring for {self.deployment_id}")
    
    def rollback_canary(self, canary_service: str):
        """Rollback canary deployment."""
        # Implementation depends on deployment system (Argo Rollouts, etc.)
        pass
    
    def promote_canary(self, canary_service: str):
        """Promote canary to stable."""
        # Implementation depends on deployment system
        pass

# Usage
if __name__ == "__main__":
    analyzer = CanaryAnalyzer(
        prometheus_url="http://prometheus:9090",
        deployment_id="canary_20251015_143000"
    )
    
    result = analyzer.analyze_canary_performance(
        canary_service="ai-gateway-canary",
        stable_service="ai-gateway-stable"
    )
    
    analyzer.execute_decision(result['decision'], "ai-gateway-canary")
```

## 5. Cost Optimization Monitoring

### Cost Tracking Dashboard

```python
# cost-monitor.py
import boto3
from datetime import datetime, timedelta
from typing import Dict, List
import json

class CostMonitor:
    def __init__(self):
        self.ce_client = boto3.client('ce', region_name='us-east-1')
        self.cloudwatch = boto3.client('cloudwatch', region_name='ap-south-1')
        
    def get_monthly_costs(self) -> Dict[str, float]:
        """Get current month costs by service."""
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        
        response = self.ce_client.get_cost_and_usage(
            TimePeriod={
                'Start': start_date,
                'End': end_date
            },
            Granularity='MONTHLY',
            Metrics=['BlendedCost'],
            GroupBy=[
                {
                    'Type': 'DIMENSION',
                    'Key': 'SERVICE'
                }
            ]
        )
        
        costs = {}
        for result in response['ResultsByTime'][0]['Groups']:
            service = result['Keys'][0]
            cost = float(result['Metrics']['BlendedCost']['Amount'])
            costs[service] = cost
            
        return costs
    
    def get_ai_token_usage(self) -> Dict[str, int]:
        """Get Claude Sonnet 4.5 token usage."""
        # This would integrate with Amazon Bedrock metrics
        # Placeholder implementation
        return {
            'input_tokens': 2100000,
            'output_tokens': 850000,
            'total_cost_usd': 42.50
        }
    
    def check_budget_alerts(self):
        """Check if we're approaching budget limits."""
        costs = self.get_monthly_costs()
        ai_usage = self.get_ai_token_usage()
        
        # Convert costs to INR (approximate)
        usd_to_inr = 83
        total_aws_cost_inr = sum(costs.values()) * usd_to_inr
        ai_cost_inr = ai_usage['total_cost_usd'] * usd_to_inr
        
        monthly_budget_inr = 300000  # 3L INR
        
        alerts = []
        
        if total_aws_cost_inr > monthly_budget_inr * 0.8:
            alerts.append({
                'type': 'budget_warning',
                'message': f'AWS costs at {total_aws_cost_inr/monthly_budget_inr*100:.1f}% of monthly budget',
                'severity': 'warning' if total_aws_cost_inr < monthly_budget_inr * 0.9 else 'critical'
            })
        
        if ai_cost_inr > monthly_budget_inr * 0.4:  # AI should be <40% of budget
            alerts.append({
                'type': 'ai_cost_warning',
                'message': f'AI costs at {ai_cost_inr/monthly_budget_inr*100:.1f}% of monthly budget',
                'severity': 'warning'
            })
        
        return alerts
    
    def optimize_costs(self):
        """Suggest cost optimization actions."""
        recommendations = []
        
        costs = self.get_monthly_costs()
        
        # Check for oversized RDS instances
        if costs.get('Amazon Relational Database Service', 0) > 50:  # $50+ USD
            recommendations.append({
                'service': 'RDS',
                'action': 'Consider downsizing instances during low traffic hours',
                'potential_saving': '20-30%'
            })
        
        # Check for unused EBS volumes
        if costs.get('Amazon Elastic Block Store', 0) > 20:
            recommendations.append({
                'service': 'EBS',
                'action': 'Identify and delete unused EBS volumes',
                'potential_saving': '10-15%'
            })
        
        return recommendations

# Automated cost monitoring
def daily_cost_check():
    monitor = CostMonitor()
    
    alerts = monitor.check_budget_alerts()
    recommendations = monitor.optimize_costs()
    
    if alerts:
        # Send to Slack/Email
        for alert in alerts:
            print(f"COST ALERT: {alert['message']}")
    
    if recommendations:
        print("COST OPTIMIZATION RECOMMENDATIONS:")
        for rec in recommendations:
            print(f"- {rec['service']}: {rec['action']} (Save: {rec['potential_saving']})")

if __name__ == "__main__":
    daily_cost_check()
```

This comprehensive AIOps configuration provides the foundation for reliable, scalable operations of the ONE Mantra platform with proactive monitoring, automated responses, and cost optimization.