# ONE Mantra - UI/UX Wireframes & Frontend Specifications

## Mobile App User Flows

### Prospect Journey Flow

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   App Launch    │───▶│  Onboarding     │───▶│   Registration  │
│                 │    │  (3 screens)    │    │   /Login        │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
┌─────────────────┐    ┌─────────────────┐             ▼
│  Property       │◀───│   AI Chatbot    │    ┌─────────────────┐
│  Discovery      │    │   Interaction   │◀───│  Home Dashboard │
└─────────────────┘    └─────────────────┘    └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Property      │    │   Lead          │    │   Profile       │
│   Details       │    │   Qualification │    │   Management    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
        │                       │
        ▼                       ▼
┌─────────────────┐    ┌─────────────────┐
│   VR Tour       │    │   Site Visit    │
│   Viewer        │    │   Booking       │
└─────────────────┘    └─────────────────┘
        │                       │
        └───────┬───────────────┘
                ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Expression    │───▶│   Document      │───▶│   Payment       │
│   of Interest   │    │   Upload        │    │   Processing    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │   Booking       │
                                               │   Confirmation  │
                                               └─────────────────┘
```

### Resident Journey Flow

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Society       │───▶│   Dashboard     │───▶│   Maintenance   │
│   Onboarding    │    │   Overview      │    │   Requests      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │                       │
                                ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Visitor       │◀───│   Quick Actions │───▶│   Amenity       │
│   Management    │    │   Menu          │    │   Booking       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   QR Code       │    │   Community     │    │   Payment       │
│   Generation    │    │   Feed          │    │   History       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Channel Partner Flow

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Partner       │───▶│   Dashboard     │───▶│   Lead          │
│   Login         │    │   Metrics       │    │   Management    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │                       │
                                ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Commission    │◀───│   Team          │    │   Lead          │
│   Tracker       │    │   Management    │    │   Registration  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Payout        │    │   Performance   │    │   Site Visit    │
│   Requests      │    │   Analytics     │    │   Coordination  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Screen Wireframes

### Home Dashboard (Prospect)

```
╔═══════════════════════════════════════════════╗
║ ☰  ONE Mantra                    🔔 👤        ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  🏠 Hi [Name], find your dream home           ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 🔍 Search properties, locations...      │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  📍 Popular Locations                         ║
║  [Kharadi] [Undri] [Wakad] [More...]         ║
║                                               ║
║  🏢 Featured Properties                       ║
║  ┌─────────────┐ ┌─────────────┐             ║
║  │ [Property 1]│ │ [Property 2]│             ║
║  │ Image       │ │ Image       │             ║
║  │ ₹1.2Cr     │ │ ₹85L        │             ║
║  │ 3BHK       │ │ 2BHK        │             ║
║  │ Ready      │ │ 2026        │             ║
║  └─────────────┘ └─────────────┘             ║
║                                               ║
║  💬 Chat with AI Assistant                    ║
║  "How can I help you today?"                  ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Type your message...                    │  ║
║  └─────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════╝
║ [🏠] [💼] [📊] [👤] ← Bottom Navigation        ║
╚═══════════════════════════════════════════════╝
```

### Property Details Screen

```
╔═══════════════════════════════════════════════╗
║ ← Mantra Essence                    ❤ 📤      ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  [========== Image Carousel ==========]      ║
║  •••••                               4/10     ║
║                                               ║
║  🏢 Mantra Essence                            ║
║  📍 Undri, Pune                              ║
║  💰 Starting from ₹1.45 Cr                   ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 🚀 Launch VR Tour                       │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  📋 Overview                                  ║
║  • 2, 3 BHK Apartments                       ║
║  • Possession: Q4 2026                       ║
║  • RERA: P52100047890                        ║
║                                               ║
║  🏊 Amenities (12)                           ║
║  [Swimming] [Gym] [Club] [More...]           ║
║                                               ║
║  📍 Location & Connectivity                   ║
║  [========== Map View ==========]            ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 📞 Schedule Site Visit                   │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ ✉️ Express Interest                      │  ║
║  └─────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════╝
```

### AI Chatbot Interface

```
╔═══════════════════════════════════════════════╗
║ ← AI Assistant                        🔊       ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  🤖 Hi! I'm your AI property advisor          ║
║      How can I help you today?                ║
║                                    10:30 AM   ║
║                                               ║
║        Looking for 3BHK under 2Cr in Pune 🏠 ║
║                                    10:31 AM   ║
║                                               ║
║  🤖 Great! I found 5 properties matching      ║
║      your criteria. What's your timeline?     ║
║                                    10:31 AM   ║
║                                               ║
║      Within 6 months                          ║
║                                    10:32 AM   ║
║                                               ║
║  🤖 Perfect! Based on your budget and         ║
║      timeline, I recommend:                   ║
║      • Mantra Essence (Ready to move)         ║
║      • Mantra Serenity (Possession 2026)      ║
║                                               ║
║      Would you like to see detailed info      ║
║      or schedule a site visit? 🏡             ║
║                                    10:33 AM   ║
║                                               ║
║  ┌─────────────┐ ┌─────────────┐             ║
║  │ 📱 Property │ │ 📅 Site     │             ║
║  │   Details   │ │    Visit    │             ║
║  └─────────────┘ └─────────────┘             ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Type your message...              📎 🎤 │  ║
║  └─────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════╝
```

### Society Dashboard (Resident)

```
╔═══════════════════════════════════════════════╗
║ ☰  ONE Mantra                    🔔 👤        ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  🏠 Welcome back, [Name]                      ║
║  🏢 Block A, Unit 101                         ║
║                                               ║
║  📊 Quick Stats                               ║
║  ┌─────────┐ ┌─────────┐ ┌─────────┐         ║
║  │   💧    │ │   ⚡    │ │   🚗    │         ║
║  │  Water  │ │Electric │ │Parking │         ║
║  │  Normal │ │ ₹2,450  │ │  A-15  │         ║
║  └─────────┘ └─────────┘ └─────────┘         ║
║                                               ║
║  🎯 Quick Actions                             ║
║  ┌─────────┐ ┌─────────┐ ┌─────────┐         ║
║  │ 🔧      │ │ 👥      │ │ 🏊      │         ║
║  │Maintenance│ │Visitor  │ │Amenity │         ║
║  │Request   │ │ Entry   │ │Booking │         ║
║  └─────────┘ └─────────┘ └─────────┘         ║
║                                               ║
║  ┌─────────┐ ┌─────────┐ ┌─────────┐         ║
║  │ 💰      │ │ 📋      │ │ 🆘      │         ║
║  │Payment  │ │Notice   │ │Emergency│         ║
║  │History  │ │ Board   │ │  SOS    │         ║
║  └─────────┘ └─────────┘ └─────────┘         ║
║                                               ║
║  📢 Recent Announcements                      ║
║  • Swimming pool maintenance - Oct 20-22      ║
║  • AGM scheduled for Nov 15, 2025            ║
║                                               ║
║  🎫 Active Requests (2)                       ║
║  • Plumbing - Unit 101 ⏳ In Progress         ║
║  • AC Service - Unit 101 ✅ Completed         ║
╚═══════════════════════════════════════════════╝
║ [🏠] [🔧] [👥] [📊] [👤] ← Bottom Navigation   ║
╚═══════════════════════════════════════════════╝
```

### Maintenance Request Form

```
╔═══════════════════════════════════════════════╗
║ ← New Maintenance Request              📎      ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  🔧 Report an Issue                           ║
║                                               ║
║  📋 Category *                                ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Plumbing                         ▼      │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  🚨 Priority                                  ║
║  ○ Low   ●Medium   ○ High   ○ Critical       ║
║                                               ║
║  📝 Title *                                   ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Kitchen sink water leakage              │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  📋 Description *                             ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Water is leaking from under the sink   │  ║
║  │ causing puddles on the floor. Started  │  ║
║  │ yesterday evening.                      │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  📸 Photos (Optional)                         ║
║  ┌───────┐ ┌───────┐ ┌───────┐               ║
║  │ [IMG] │ │ [IMG] │ │  📷   │               ║
║  │  1/3  │ │  2/3  │ │  Add  │               ║
║  └───────┘ └───────┘ └───────┘               ║
║                                               ║
║  🏠 Location Details                          ║
║  ┌─────────────────────────────────────────┐  ║
║  │ Kitchen area, under the main sink       │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 📨 Submit Request                        │  ║
║  └─────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════╝
```

### Visitor Management Screen

```
╔═══════════════════════════════════════════════╗
║ ← Visitor Management                  + Add    ║
╠═══════════════════════════════════════════════╣
║                                               ║
║  👥 Today's Visitors                          ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 👤 John Smith                           │  ║
║  │ 📞 +91 98765 43210                      │  ║
║  │ 🚗 MH12 AB 1234                         │  ║
║  │ ⏰ 2:00 PM - 4:00 PM                    │  ║
║  │ 🎯 Family Visit                         │  ║
║  │                          ✅ Approved    │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 🚚 Amazon Delivery                      │  ║
║  │ 📞 +91 87654 32109                      │  ║
║  │ 🎯 Package Delivery                     │  ║
║  │ ⏰ 11:30 AM - 12:00 PM                  │  ║
║  │                       ⏳ Checked In     │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 👤 Sarah Johnson                        │  ║
║  │ 📞 +91 76543 21098                      │  ║
║  │ 🎯 Real Estate Agent                    │  ║
║  │ ⏰ 4:00 PM - 5:00 PM                    │  ║
║  │                         ⏳ Pending      │  ║
║  │ [✅ Approve] [❌ Reject]                │  ║
║  └─────────────────────────────────────────┘  ║
║                                               ║
║  📊 Quick Stats                               ║
║  Today: 15 visitors | This week: 47          ║
║                                               ║
║  ┌─────────────────────────────────────────┐  ║
║  │ 📱 Generate QR Code for Frequent Visitor│  ║
║  └─────────────────────────────────────────┘  ║
╚═══════════════════════════════════════════════╝
```

## Web Admin Portal Wireframes

### Admin Dashboard

```
╔══════════════════════════════════════════════════════════════════╗
║ ONE Mantra Admin                              🔔 Admin User ⚙️   ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║ [Dashboard] [Properties] [Leads] [Users] [Analytics] [Settings]  ║
║                                                                  ║
║ 📊 Key Metrics                                    Oct 15, 2025   ║
║ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────┐ ║
║ │ 📈 New Leads │ │ 🏠 Properties│ │ 💰 Revenue   │ │ 👥 Users │ ║
║ │     847      │ │      23      │ │  ₹12.5 Cr    │ │  5,420   │ ║
║ │  ↗️ +12%     │ │   ↗️ +2      │ │  ↗️ +8%      │ │ ↗️ +156  │ ║
║ └──────────────┘ └──────────────┘ └──────────────┘ └──────────┘ ║
║                                                                  ║
║ 📈 Lead Conversion Funnel                                        ║
║ ┌────────────────────────────────────────────────────────────┐   ║
║ │ Enquiry [████████████] 1,245                               │   ║
║ │ Qualified [████████] 892                                   │   ║
║ │ Site Visit [██████] 567                                    │   ║
║ │ EOI [████] 234                                             │   ║
║ │ Booking [██] 89                                            │   ║
║ └────────────────────────────────────────────────────────────┘   ║
║                                                                  ║
║ 🤖 AI Performance                   📋 Recent Activities         ║
║ ┌──────────────────────────────┐   ┌──────────────────────────┐  ║
║ │ Response Accuracy: 94.2%     │   │ • New lead from Kharadi  │  ║
║ │ Avg Response Time: 1.2s      │   │ • Booking confirmed A302 │  ║
║ │ Handoff Rate: 8.5%           │   │ • Maintenance req B101   │  ║
║ │ User Satisfaction: 4.6/5     │   │ • Commission paid P001   │  ║
║ └──────────────────────────────┘   └──────────────────────────┘  ║
║                                                                  ║
║ 🚨 Alerts & Notifications                                        ║
║ • High error budget burn rate detected (5 min ago)              ║
║ • Payment retry failed for Booking B-4567 (12 min ago)          ║
║ • New channel partner registration pending (1 hour ago)         ║
╚══════════════════════════════════════════════════════════════════╝
```

### Lead Management Interface

```
╔══════════════════════════════════════════════════════════════════╗
║ Lead Management                              🔍 Search  📊 Export ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║ Filters: [All Status ▼] [All Sources ▼] [All Partners ▼]        ║
║                                                                  ║
║ ┌────────────────────────────────────────────────────────────────┐ ║
║ │ Lead ID | Name      | Source    | Status    | Score | Actions│ ║
║ ├────────────────────────────────────────────────────────────────┤ ║
║ │ L-4567  │ John Doe  │ Website   │ Qualified │  85   │ 👁️ 📝 │ ║
║ │ L-4568  │ Sarah S.  │ Referral  │ New       │  -    │ 👁️ 📝 │ ║
║ │ L-4569  │ Mike R.   │ Partner   │ Contacted │  72   │ 👁️ 📝 │ ║
║ │ L-4570  │ Lisa W.   │ Social    │ Visited   │  91   │ 👁️ 📝 │ ║
║ │ L-4571  │ David L.  │ NRI Desk  │ EOI       │  88   │ 👁️ 📝 │ ║
║ └────────────────────────────────────────────────────────────────┘ ║
║                                                                  ║
║ Lead Details Panel (L-4567)                                      ║
║ ┌────────────────────────────────────────────────────────────────┐ ║
║ │ 👤 John Doe                          📧 john@email.com        │ ║
║ │ 📞 +91 98765 43210                   📍 Pune, Maharashtra     │ ║
║ │                                                               │ ║
║ │ 🎯 BANT Qualification Score: 85/100                           │ ║
║ │ ✅ Budget: ₹1.5-2Cr    ✅ Authority: Primary Decision Maker   │ ║
║ │ ✅ Need: Immediate     ✅ Timeline: 3-6 months                │ ║
║ │                                                               │ ║
║ │ 🤖 AI Insights:                                               │ ║
║ │ • High intent signals in conversation                         │ ║
║ │ • Interested in 3BHK properties                               │ ║
║ │ • Prefers ready-to-move options                               │ ║
║ │                                                               │ ║
║ │ 📝 Recommended Actions:                                       │ ║
║ │ 1. Schedule site visit for Mantra Essence                    │ ║
║ │ 2. Share detailed brochure and payment plan                  │ ║
║ │ 3. Follow up within 24 hours                                 │ ║
║ │                                                               │ ║
║ │ [📅 Schedule Visit] [📧 Send Brochure] [🎯 Assign Partner]   │ ║
║ └────────────────────────────────────────────────────────────────┘ ║
╚══════════════════════════════════════════════════════════════════╝
```

### AI Operations Dashboard

```
╔══════════════════════════════════════════════════════════════════╗
║ AI Operations Dashboard                        🔄 Refresh  ⚙️ Config ║
╠══════════════════════════════════════════════════════════════════╣
║                                                                  ║
║ 🤖 Model Performance                           📊 Token Usage    ║
║ ┌────────────────────────────────────┐       ┌─────────────────┐ ║
║ │ Model: Claude Sonnet 4.5           │       │ This Month      │ ║
║ │ Status: ✅ Healthy                 │       │ ────────────── │ ║
║ │ Accuracy: 94.2% (↗️ +1.2%)         │       │ Used: 2.1M      │ ║
║ │ Avg Latency: 1.8s (↘️ -0.3s)      │       │ Budget: 5M      │ ║
║ │ Error Rate: 0.08% (↘️ -0.02%)      │       │ Cost: ₹1.2L     │ ║
║ └────────────────────────────────────┘       └─────────────────┘ ║
║                                                                  ║
║ 📝 Prompt Management                                             ║
║ ┌────────────────────────────────────────────────────────────────┐ ║
║ │ Prompt Name      │ Version │ Status   │ Performance │ Actions │ ║
║ ├────────────────────────────────────────────────────────────────┤ ║
║ │ Lead Qualification│ v2.1    │ 🟢 Live  │ 94.2%      │ 📝 ✨ 📊 │ ║
║ │ Objection Handling│ v1.8    │ 🔄 Canary│ 91.5%      │ 📝 ✨ 📊 │ ║
║ │ Site Visit Coord  │ v1.5    │ 🟢 Live  │ 96.1%      │ 📝 ✨ 📊 │ ║
║ │ Grievance Triage  │ v2.0    │ 🔄 Canary│ 88.7%      │ 📝 ✨ 📊 │ ║
║ └────────────────────────────────────────────────────────────────┘ ║
║                                                                  ║
║ 🔥 Canary Deployments                                            ║
║ ┌────────────────────────────────────────────────────────────────┐ ║
║ │ Objection Handling v1.8                                       │ ║
║ │ Traffic: 5% │ Duration: 18h remaining │ Performance: 91.5%    │ ║
║ │ [📊 View Metrics] [✅ Promote] [❌ Rollback]                  │ ║
║ └────────────────────────────────────────────────────────────────┘ ║
║                                                                  ║
║ 🚨 Alerts & SLO Status                                           ║
║ • ✅ Error Budget: 87% remaining                                 ║
║ • ✅ Response Time SLO: 98.5% compliance                         ║
║ • ⚠️ Handoff Rate: 8.5% (target: <8%)                           ║
║ • ✅ User Satisfaction: 4.6/5 (target: >4.0)                    ║
╚══════════════════════════════════════════════════════════════════╝
```

## Component Library Specifications

### Design System Tokens

```typescript
// Design tokens
export const tokens = {
  colors: {
    primary: {
      50: '#e8f2ff',
      100: '#d1e6ff',
      500: '#1a73e8',
      600: '#1557b0',
      700: '#104079',
      900: '#0d2a42'
    },
    success: {
      50: '#e6f7e6',
      500: '#4caf50',
      700: '#2e7d32'
    },
    warning: {
      50: '#fff8e1',
      500: '#ff9800',
      700: '#f57c00'
    },
    error: {
      50: '#ffebee',
      500: '#f44336',
      700: '#d32f2f'
    },
    neutral: {
      50: '#fafafa',
      100: '#f5f5f5',
      300: '#e0e0e0',
      500: '#9e9e9e',
      700: '#616161',
      900: '#212121'
    }
  },
  
  typography: {
    fontFamily: {
      primary: 'Inter, system-ui, sans-serif',
      mono: 'Fira Code, monospace'
    },
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '3xl': '1.875rem'
    },
    fontWeight: {
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700
    },
    lineHeight: {
      tight: 1.25,
      normal: 1.5,
      relaxed: 1.75
    }
  },
  
  spacing: {
    0: '0',
    1: '0.25rem',
    2: '0.5rem',
    3: '0.75rem',
    4: '1rem',
    5: '1.25rem',
    6: '1.5rem',
    8: '2rem',
    10: '2.5rem',
    12: '3rem',
    16: '4rem'
  },
  
  borderRadius: {
    none: '0',
    sm: '0.25rem',
    base: '0.375rem',
    md: '0.5rem',
    lg: '0.75rem',
    xl: '1rem',
    full: '50%'
  },
  
  shadows: {
    sm: '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)',
    base: '0 3px 6px rgba(0,0,0,0.15), 0 2px 4px rgba(0,0,0,0.12)',
    lg: '0 10px 20px rgba(0,0,0,0.15), 0 3px 6px rgba(0,0,0,0.10)',
    xl: '0 15px 25px rgba(0,0,0,0.15), 0 5px 10px rgba(0,0,0,0.05)'
  }
};
```

### Core Components

```typescript
// Button Component
interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'xs' | 'sm' | 'base' | 'lg' | 'xl';
  children: React.ReactNode;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  isLoading?: boolean;
  isDisabled?: boolean;
  onPress?: () => void;
}

// Input Component
interface InputProps {
  label?: string;
  placeholder?: string;
  value?: string;
  onChangeText?: (text: string) => void;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'email-address' | 'phone-pad' | 'numeric';
  multiline?: boolean;
  numberOfLines?: number;
}

// Card Component
interface CardProps {
  children: React.ReactNode;
  variant?: 'elevated' | 'outlined' | 'filled';
  padding?: 'none' | 'sm' | 'base' | 'lg';
  onPress?: () => void;
}

// Modal Component
interface ModalProps {
  isVisible: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  closeOnOverlayPress?: boolean;
}

// Toast/Snackbar Component
interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  action?: {
    label: string;
    onPress: () => void;
  };
}
```

### Responsive Design Guidelines

```typescript
// Breakpoints
export const breakpoints = {
  mobile: 320,
  tablet: 768,
  desktop: 1024,
  largeDesktop: 1440
};

// Grid System
export const grid = {
  columns: 12,
  gutterWidth: 16,
  margins: {
    mobile: 16,
    tablet: 24,
    desktop: 32
  }
};

// Layout Guidelines
export const layouts = {
  maxWidth: {
    mobile: '100%',
    tablet: '768px',
    desktop: '1200px'
  },
  
  navigation: {
    height: {
      mobile: 56,
      tablet: 64,
      desktop: 72
    }
  },
  
  sidebar: {
    width: {
      collapsed: 72,
      expanded: 280
    }
  }
};
```

This comprehensive UI/UX specification provides the foundation for building consistent, accessible, and user-friendly interfaces across all platforms of the ONE Mantra ecosystem.